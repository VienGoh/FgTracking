﻿Imports DevExpress.XtraEditors
Imports DevExpress.XtraGrid

Public Interface iclsList
    Function Action(ByVal DataRow As DataRow, ByVal ActionType As String) As Boolean
    Function CallTypeList() As List(Of iclsCallType)
    Function RefreshData() As DataTable
    Function CustomFormat() As Dictionary(Of String, String)
    Function ConditionalFormat() As Dictionary(Of String, FormatConditionRuleExpression)
    Function ColumnNumToFreeze() As String
    Function AddonText() As String
    Function SummaryColumn() As List(Of GridColumnSummaryItem)
    Function FontGridView() As Object
    Function GroupSum() As List(Of GridGroupSummaryItem)
End Interface
