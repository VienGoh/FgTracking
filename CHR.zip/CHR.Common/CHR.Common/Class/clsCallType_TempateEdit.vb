﻿Public Class clsCallType_TempateEdit
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cEdit
        MyBase._name = cEdit
        MyBase._image = cEdit
    End Sub

End Class
