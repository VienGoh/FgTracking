﻿using System;

namespace DataModel
{
    public class Class1
    {
    }
}
