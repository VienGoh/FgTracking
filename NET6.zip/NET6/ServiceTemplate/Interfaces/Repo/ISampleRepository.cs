using DataModel.Contexts;
using DataModel.Entities;
using MMH.HelperService.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceTemplate.Interfaces.Repo
{
  public interface ISampleRepository : IBaseRepository<LocalDbContext, Sample>
  {
    public Sample CustomizeOwnAddRecord();
    public Sample CustomizeOwnUpdateRecord(Sample obj);
  }
  public interface ISampleDetailRepository : IBaseRepository<LocalDbContext, SampleDetail>
  {
    public SampleDetail CustomizeOwnAddRecordWithCascadeAdd();
    public SampleDetail CustomizeOwnUpdateRecordWithCascadeUpdate(SampleDetail obj);
    public SampleDetail TestA(int id);
  }
}
