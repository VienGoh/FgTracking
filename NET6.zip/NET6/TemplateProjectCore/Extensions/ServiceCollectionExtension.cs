using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Telerik.Reporting.Services;
using Telerik.Reporting.Cache.File;
using MMH.HelperService.Interfaces.Repositories;

namespace TemplateProjectCore.Extensions
{
  public static class ServiceCollectionExtension
  {
    public static void AddLocalServices(this IServiceCollection services)
    {
      // Configure dependencies for ReportsController.(NET5)
      //services.TryAddSingleton<IReportServiceConfiguration>(sp =>
      //   new ReportServiceConfiguration
      //   {
      //       //ReportingEngineConfiguration = ConfigurationHelper.ResolveConfiguration(sp.GetService<IWebHostEnvironment>()),
      //       HostAppId = "Net5RestServiceWithCors",
      //       Storage = new FileStorage(),
      //       ReportSourceResolver = new UriReportSourceResolver(
      //           System.IO.Path.Combine(sp.GetService<IWebHostEnvironment>().ContentRootPath, "Reports"))
      //   });

      services.TryAddSingleton<IReportServiceConfiguration>(sp =>
          new ReportServiceConfiguration
          {
            // The default ReportingEngineConfiguration will be initialized from appsettings.json or appsettings.{EnvironmentName}.json:
            ReportingEngineConfiguration = sp.GetService<IConfiguration>(),
            // In case the ReportingEngineConfiguration needs to be loaded from a specific configuration file, use the approach below:
            //ReportingEngineConfiguration = ResolveSpecificReportingConfiguration(sp.GetService<IWebHostEnvironment>()),
            HostAppId = "ReportingNet6",
            Storage = new FileStorage(),
            ReportSourceResolver = new UriReportSourceResolver(System.IO.Path.Combine(sp.GetService<IWebHostEnvironment>().ContentRootPath, "Reports"))
          });


    }


    public static void AddIIIIIIIIServices(this IServiceCollection services)
    {
      AppDomain.CurrentDomain.GetAssemblies()
          .SelectMany(s =>
          {
            try { return s.GetTypes(); }
            catch (Exception ex) { return Type.EmptyTypes; }
          })
          .Where(s => typeof(IBaseRepository<,>).IsAssignableFrom(s))
          .Where(s => !s.IsAbstract)
          .Where(s => s.IsClass)
          .Select(s =>
          {
            services.AddScoped(s);
            return services.AddScoped(sp => sp.CreateScope().ServiceProvider.GetService(s));
          })
          .ToList();
    }







  }

}
