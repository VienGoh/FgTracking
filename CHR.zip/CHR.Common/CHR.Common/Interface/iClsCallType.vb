﻿Public Interface iclsCallType
    Property Name As String
    Property FriendlyName As String
    Property Image As String

End Interface
