﻿Public Module modConstanta
    Public Const cView As String = "View"
    Public Const cNew As String = "New"
    Public Const cEdit As String = "Edit"
    Public Const cDelete As String = "Delete"
    Public Const cRefresh As String = "Refresh"
    Public Const cFilter As String = "Filter"
    Public Const cPrint As String = "Print"
    Public Const cPrinter As String = "Printer"
    Public Const cPrintPreview As String = "Print Preview"
    Public Const cReport As String = "Report"
    Public Const cClose As String = "Close"
    Public Const cExit As String = "Exit"
End Module
