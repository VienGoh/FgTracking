﻿Public Module modString
    Public Sub AppendString(ByRef StringToAppend As String, ByVal StringToAdd As String, ByVal Separator As String)
        If StringToAppend = "" Then
            StringToAppend = StringToAdd
        Else
            StringToAppend = StringToAppend & Separator & StringToAdd
        End If

    End Sub
End Module
