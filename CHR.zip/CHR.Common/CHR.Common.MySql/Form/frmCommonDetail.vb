﻿Imports System.Text.RegularExpressions
Imports DevExpress.XtraEditors.Controls
Imports DevExpress.XtraEditors.Repository
Imports DevExpress.XtraVerticalGrid
Imports DevExpress.XtraVerticalGrid.Rows
Imports DevExpress.XtraVerticalGrid.ViewInfo

Public Class frmCommonDetail

    Private _isFirstLoad As Boolean = True
    Private _listCustomItem As List(Of Object)
    Private _rowDescription As New Dictionary(Of String, String)
    Private _rowNullTrimSetting As New Dictionary(Of String, Dictionary(Of String, Boolean))

    Public ReadOnly Property IsOk As Boolean
        Get
            If Me.DialogResult = DialogResult.OK Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public WriteOnly Property ListCustomItem As List(Of Object)
        Set(value As List(Of Object))
            _listCustomItem = value
        End Set
    End Property

    Private _dataSource As DataTable
    Public WriteOnly Property DataSource As DataTable
        Set(value As DataTable)
            _dataSource = value
        End Set
    End Property

    Public ReadOnly Property Result As DataRow
        Get
            Return _dataSource.Rows(0)
        End Get
    End Property

    Private _schema As DataTable
    Public WriteOnly Property Schema As DataTable
        Set(value As DataTable)
            _schema = value
        End Set
    End Property

    Private _isForView As Boolean = False
    Public WriteOnly Property IsForView As Boolean
        Set(value As Boolean)
            _isForView = value
        End Set
    End Property

    Private _isForDelete As Boolean = False
    Public WriteOnly Property IsForDelete As Boolean
        Set(value As Boolean)
            _isForDelete = value
        End Set
    End Property

    Private _buttonSaveText As String = "Save"
    Public WriteOnly Property ButtonSaveText As String
        Set(value As String)
            _buttonSaveText = value
        End Set
    End Property

    Private Sub frmCommonDetail_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not _isFirstLoad Then Exit Sub

        For Each col As DataColumn In _schema.Columns
            AddNewChildRow(col)
        Next

        For Each row As BaseRow In VGridControl1.Rows
            row.Properties.Value = _dataSource.Rows(0).Item(row.Properties.FieldName)
            _rowDescription.Add(row.Properties.FieldName, row.Properties.Caption)

            Dim settingDict As New Dictionary(Of String, Boolean)
            settingDict.Add("AllowNull", True)
            settingDict.Add("AllowTrimEmptyString", True)
            _rowNullTrimSetting.Add(row.Properties.FieldName, settingDict)
        Next

        If _listCustomItem IsNot Nothing Then
            For Each lCustomItem As Object In _listCustomItem

                Dim row As BaseRow = VGridControl1.GetRowByFieldName(GetPropertyValue(lCustomItem, "RowName"))
                row.Properties.Caption = GetPropertyValue(lCustomItem, "RowFriendlyName")
                row.Properties.ReadOnly = GetPropertyValue(lCustomItem, "IsReadOnly") Or _isForView Or _isForDelete
                row.Visible = GetPropertyValue(lCustomItem, "IsVisible")

                'set warna dan style khusus utk yg Not readonly
                If Not (GetPropertyValue(lCustomItem, "IsReadOnly") Or _isForView Or _isForDelete) Then
                    row.AppearanceCell.ForeColor = Color.Black
                    'row.AppearanceCell.Font = New Font("Segoe UI", 8, FontStyle.Regular)
                End If

                _rowDescription(row.Properties.FieldName) = GetPropertyValue(lCustomItem, "RowDescription")
                _rowNullTrimSetting(row.Properties.FieldName)("AllowNull") = GetPropertyValue(lCustomItem, "AllowNull")
                _rowNullTrimSetting(row.Properties.FieldName)("AllowTrimEmptyString") = GetPropertyValue(lCustomItem, "AllowTrimEmptyString")

                Dim oClsType As Type = lCustomItem.GetType()
                Select Case oClsType
                    Case GetType(clsCommonDetailItem_GridLookup)
                        Dim cCustomItem As clsCommonDetailItem_GridLookup = CType(lCustomItem, clsCommonDetailItem_GridLookup)
                        Dim ribe As New RepositoryItemButtonEdit
                        Dim buttonClear As New EditorButton With {.Kind = ButtonPredefines.Clear}
                        ribe.Buttons.Add(buttonClear)

                        'untuk passing class ke button
                        ribe.Buttons(0).Tag = cCustomItem
                        ribe.Buttons(1).Tag = cCustomItem
                        ribe.Name = cCustomItem.RowName

                        'jika readonly, maka disable kan
                        If row.Properties.ReadOnly Or _isForView Or _isForDelete Then
                            ribe.Buttons(0).Enabled = False
                            ribe.Buttons(1).Enabled = False
                        End If

                        If Not cCustomItem.EnableFreeText Then ribe.TextEditStyle = TextEditStyles.DisableTextEditor
                        row.Properties.RowEdit = ribe
                        AddHandler ribe.ButtonClick, AddressOf showFrmSelect
                    Case GetType(clsCommonDetailItem_CalcEdit)
                        Dim cCustomItem As clsCommonDetailItem_CalcEdit = CType(lCustomItem, clsCommonDetailItem_CalcEdit)
                        Dim ce As New RepositoryItemCalcEdit With {.Precision = cCustomItem.Precision, .ShowCloseButton = True}
                        row.Properties.RowEdit = ce
                    Case GetType(clsCommonDetailItem_CheckedComboBoxEdit)
                        Dim cCustomItem As clsCommonDetailItem_CheckedComboBoxEdit = CType(lCustomItem, clsCommonDetailItem_CheckedComboBoxEdit)
                        Dim ccbe As New RepositoryItemCheckedComboBoxEdit With {.SeparatorChar = cCustomItem.SeparatorChar}
                        For Each item As String In cCustomItem.Items
                            ccbe.Items.Add(item)
                        Next
                        row.Properties.RowEdit = ccbe
                    Case GetType(clsCommonDetailItem_ComboBoxEdit)
                        Dim cCustomItem As clsCommonDetailItem_ComboBoxEdit = CType(lCustomItem, clsCommonDetailItem_ComboBoxEdit)
                        Dim cbe As New RepositoryItemComboBox
                        cbe.TextEditStyle = TextEditStyles.DisableTextEditor
                        For Each item As String In cCustomItem.Items
                            cbe.Items.Add(item)
                        Next
                        row.Properties.RowEdit = cbe
                    Case GetType(clsCommonDetailItem_MemoExEdit)
                        Dim cCustomItem As clsCommonDetailItem_MemoExEdit = CType(lCustomItem, clsCommonDetailItem_MemoExEdit)
                        Dim mee As New RepositoryItemMemoExEdit
                        row.Properties.RowEdit = mee
                    Case GetType(clsCommonDetailItem_RadioGroup)
                        Dim cCustomItem As clsCommonDetailItem_RadioGroup = CType(lCustomItem, clsCommonDetailItem_RadioGroup)
                        Dim rg As New RepositoryItemRadioGroup
                        For Each s As String In cCustomItem.Items
                            Dim rgi As New RadioGroupItem With {.Value = s, .Description = s}
                            rg.Items.Add(rgi)
                        Next
                        row.Properties.RowEdit = rg
                    Case GetType(clsCommonDetailItem_SpinEdit)
                        Dim cCustomItem As clsCommonDetailItem_SpinEdit = CType(lCustomItem, clsCommonDetailItem_SpinEdit)
                        Dim se As New RepositoryItemSpinEdit With {.Increment = cCustomItem.Increment, .MinValue = cCustomItem.MinValue, .MaxValue = cCustomItem.MaxValue}
                        row.Properties.RowEdit = se
                    Case GetType(clsCommonDetailItem_LookupEdit)
                        Dim cCustomItem As clsCommonDetailItem_LookupEdit = CType(lCustomItem, clsCommonDetailItem_LookupEdit)
                        Dim dt As DataTable
                        If cCustomItem.DataSource IsNot Nothing Then
                            dt = cCustomItem.DataSource
                        Else
                            dt = GetDataTable(cCustomItem.SqlQuery, cCustomItem.ConnectionString)
                        End If
                        Dim le As New RepositoryItemLookUpEdit With {.DataSource = dt, .DisplayMember = cCustomItem.DisplayMember, .ValueMember = cCustomItem.ValueMember, .BestFitMode = BestFitMode.BestFitResizePopup, .SearchMode = SearchMode.AutoSearch}
                        row.Properties.RowEdit = le
                    Case GetType(clsCommonDetailItem_DateEdit)
                        Dim cCustomItem As clsCommonDetailItem_DateEdit = CType(lCustomItem, clsCommonDetailItem_DateEdit)
                        Dim de As New RepositoryItemDateEdit With {.CalendarTimeEditing = If(cCustomItem.ShowTime, DevExpress.Utils.DefaultBoolean.True, DevExpress.Utils.DefaultBoolean.False), .EditMask = cCustomItem.DateFormat, .UseMaskAsDisplayFormat = True, .HighlightHolidays = False}
                        row.Properties.RowEdit = de
                    Case GetType(clsCommonDetailItem_TimeEdit)
                        Dim cCustomItem As clsCommonDetailItem_TimeEdit = CType(lCustomItem, clsCommonDetailItem_TimeEdit)
                        Dim te As New RepositoryItemTimeEdit With {.EditMask = cCustomItem.TimeFormat, .UseMaskAsDisplayFormat = True}
                        row.Properties.RowEdit = te
                End Select
            Next
        End If

        AdjustHeight(VGridControl1)
        btnSave.Visible = Not _isForView
        btnSave.Text = _buttonSaveText
        _isFirstLoad = False
        BarStaticItem1.Caption = _rowDescription.Item(_schema.Columns(0).Caption)
    End Sub

    Private Sub showFrmSelect(sender As Object, e As EventArgs)
        Dim clsItem As clsCommonDetailItem_GridLookup = CType(e, ButtonPressedEventArgs).Button.Tag
        Dim buttonKind As String = CType(e, ButtonPressedEventArgs).Button.Kind

        Dim row As BaseRow = VGridControl1.GetRowByFieldName(clsItem.RowName)
        If buttonKind = "1" Then
            'button ellipsis
            Dim dt As DataTable
            If clsItem.DataSource IsNot Nothing Then
                dt = clsItem.DataSource
            Else
                dt = GetDataTable(clsItem.SqlQuery, clsItem.ConnectionString)
            End If

            Dim f As New frmSelect With {.IsMultiSelect = clsItem.IsMultiSelect, .DataSource = dt}
            If f.ShowDialog() = DialogResult.OK Then
                Dim resultDT As DataTable = f.Result
                Dim oLAR(,) As String = clsItem.LookupAndAffectedRow

                Dim oVGridControl As VGridControl = VGridControl1
                oVGridControl.Name = clsItem.RowName

                If clsItem.IsMultiSelect Then
                    If resultDT.Rows.Count > 0 Then
                        Dim str As String = ""
                        For Each oRow As DataRow In resultDT.Rows
                            AppendString(str, oRow.Item(oLAR(0, 1)), clsItem.Separator)
                        Next
                        VGridControl1.GetRowByFieldName(oLAR(0, 0)).Properties.Value = str
                        VGridControl_CellValueChanged(oVGridControl, Nothing)
                    End If
                Else
                    For i As Integer = 0 To clsItem.LookupAndAffectedRow.GetUpperBound(0)
                        VGridControl1.GetRowByFieldName(oLAR(i, 0)).Properties.Value = resultDT.Rows(0).Item(oLAR(i, 1))
                        VGridControl_CellValueChanged(oVGridControl, Nothing)
                    Next
                End If

            End If

            f.Close()
            f.Dispose()

        ElseIf buttonKind = "10" Then
            'button clear
            row.Properties.Value = ""
        End If

    End Sub

    Public Sub AddNewCategoryRow(Optional ByVal caption As String = "New CategoryRow")
        Dim newCategoryRow As New CategoryRow(caption) With {.Height = 40}
        newCategoryRow.Properties.Caption = caption
        VGridControl1.Rows.Add(newCategoryRow)
    End Sub

    Public Sub AddNewChildRow(ByVal dataColumn As DataColumn, Optional ByVal categoryRowCaption As String = "")
        Dim childRow As New EditorRow(dataColumn.Caption)
        With childRow.Properties
            .ReadOnly = True
            .RowEditName = dataColumn.Caption
            .FieldName = dataColumn.Caption
            .Caption = SetRowCaption(dataColumn.Caption)
            If dataColumn.DataType.ToString = "System.String" Then
                Dim rie As New RepositoryItemTextEdit
                With rie
                    .Name = dataColumn.Caption
                    .MaxLength = dataColumn.MaxLength
                    .ValidateOnEnterKey = True
                End With
                .RowEdit = rie
            End If
        End With

        Dim parentRow As BaseRow = VGridControl1.Rows("category" & categoryRowCaption)
        VGridControl1.Rows.Add(childRow)
        VGridControl1.MoveRow(childRow, parentRow, False)
    End Sub

    Private Function SetRowCaption(ByVal Caption As String) As String
        Dim colCaption As String = Caption.Replace("_", " ")
        colCaption = Regex.Replace(colCaption, "([a-z])([A-Z])", "$1 $2")

        Return colCaption
    End Function

    Private Sub ReadVGrid()
        For Each row As BaseRow In VGridControl1.Rows
            _dataSource.Rows(0).Item(row.Properties.FieldName) = IsNulls(row.Properties.Value, System.DBNull.Value)
        Next
    End Sub

    Private Function IsValid() As Boolean
        IsValid = False

        Try
            Dim errorMessage As String = ""
            For Each row As BaseRow In VGridControl1.Rows
                Dim rowName As String = row.Properties.FieldName
                Dim rowErrorMessage As String = ""
                If Not _rowNullTrimSetting(rowName)("AllowNull") And (IsNothing(row.Properties.Value) Or IsDBNull(row.Properties.Value)) Then AppendString(rowErrorMessage, "[Not Null]", vbCrLf)
                If Not _rowNullTrimSetting(rowName)("AllowTrimEmptyString") And Trim(IsNulls(row.Properties.Value, "")) = "" Then AppendString(rowErrorMessage, "[Not Empty String]", vbCrLf)
                If rowErrorMessage <> "" Then AppendString(errorMessage, "Invalid value on [" & rowName & "]" & rowErrorMessage, vbCrLf)
            Next
            If errorMessage = "" Then
                IsValid = True
            Else
                mbError(errorMessage, "Invalid Value")
            End If
        Catch ex As Exception
            mbError(ex.ToString)
        End Try

    End Function

    Private Sub VGridControl1_FocusedRowChanged(sender As Object, e As DevExpress.XtraVerticalGrid.Events.FocusedRowChangedEventArgs) Handles VGridControl1.FocusedRowChanged
        If VGridControl1.FocusedRow IsNot Nothing Then
            Dim x = VGridControl1.FocusedRow.Properties.FieldName
            Dim y As String = ""

            If _rowDescription.TryGetValue(x, y) Then
                BarStaticItem1.Caption = y
            End If

        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        VGridControl1.CloseEditor()
        If Not IsValid() Then Exit Sub

        ReadVGrid()

        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub AdjustHeight(ByVal grid As VGridControl)
        Dim viewInfo As BaseViewInfo = grid.ViewInfo
        Dim totalHeight As Integer = 0

        grid.Height = Int32.MaxValue
        totalHeight += viewInfo.ViewRects.Client.Location.Y

        For Each row As BaseRow In VGridControl1.Rows
            totalHeight += viewInfo.GetVisibleRowHeight(row)
            Dim rowViewInfo As BaseRowViewInfo = viewInfo.RowsViewInfo.OfType(Of BaseRowViewInfo)().Where(Function(r) Object.ReferenceEquals(r.Row, row)).FirstOrDefault()

            If rowViewInfo IsNot Nothing Then
                totalHeight += 2
            End If
        Next row

        If viewInfo.Scroller.ScrollInfo.HScrollVisible Then
            totalHeight += viewInfo.Scroller.ScrollInfo.VScrollWidth
        End If

        grid.Height = totalHeight

        Dim fHeight As Integer = If(totalHeight + 100 > 700, 700, totalHeight + 100)
        Height = fHeight

        'MaximumSize = New System.Drawing.Size(2048, fHeight)
        MinimumSize = New System.Drawing.Size(0, fHeight)
    End Sub

    Public Function GetPropertyValue(ByVal obj As Object, ByVal PropName As String) As Object
        Dim objType As Type = obj.GetType()
        Dim pInfo As System.Reflection.PropertyInfo = objType.GetProperty(PropName)
        Dim PropValue As Object = pInfo.GetValue(obj, Reflection.BindingFlags.GetProperty, Nothing, Nothing, Nothing)
        Return PropValue
    End Function

    Public Overridable Sub VGridControl_CellValueChanged(sender As Object, e As Events.CellValueChangedEventArgs) Handles VGridControl1.CellValueChanged

    End Sub

End Class