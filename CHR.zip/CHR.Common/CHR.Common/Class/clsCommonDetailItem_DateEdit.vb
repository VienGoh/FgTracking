﻿Public Class clsCommonDetailItem_DateEdit
    Inherits clsCommonDetailItem

    Private _dateFormat As String = "MM/dd/yyyy"
    Public Property DateFormat As String
        Set(value As String)
            _dateFormat = value
        End Set
        Get
            Return _dateFormat
        End Get
    End Property

    Private _showTime As Boolean
    Public Property ShowTime As Boolean
        Set(value As Boolean)
            _showTime = value
        End Set
        Get
            Return _showTime
        End Get
    End Property
End Class
