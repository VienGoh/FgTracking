﻿Public Class clsCommonDetailItem

    Private _isVisible As Boolean = True
    Public Property IsVisible As Boolean
        Set(value As Boolean)
            _isVisible = value
        End Set
        Get
            Return _isVisible
        End Get
    End Property

    Private _isReadOnly As Boolean = False
    Public Property IsReadOnly As Boolean
        Set(value As Boolean)
            _isReadOnly = value
        End Set
        Get
            Return _isReadOnly
        End Get
    End Property

    Private _isEnabled As Boolean = True
    Public Property IsEnabled As Boolean
        Set(value As Boolean)
            _isEnabled = value
        End Set
        Get
            Return _isEnabled
        End Get
    End Property

    Private _rowName As String
    Public Property RowName As String
        Set(value As String)
            _rowName = value
        End Set
        Get
            Return _rowName
        End Get
    End Property

    Private _rowFriendlyName As String
    Public Property RowFriendlyName As String
        Set(value As String)
            _rowFriendlyName = value
        End Set
        Get
            Return _rowFriendlyName
        End Get
    End Property

    Private _rowDescription As String
    Public Property RowDescription As String
        Set(value As String)
            _rowDescription = value
        End Set
        Get
            Return _rowDescription
        End Get
    End Property

    Private _allowNull As Boolean = True
    Public Property AllowNull As Boolean
        Set(value As Boolean)
            _allowNull = value
        End Set
        Get
            Return _allowNull
        End Get
    End Property

    Private _allowTrimEmptyString As Boolean = True
    Public Property AllowTrimEmptyString As Boolean
        Set(value As Boolean)
            _allowTrimEmptyString = value
        End Set
        Get
            Return _allowTrimEmptyString
        End Get
    End Property
End Class
