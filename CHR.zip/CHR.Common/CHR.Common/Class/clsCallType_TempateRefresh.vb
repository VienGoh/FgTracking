﻿Public Class clsCallType_TempateRefresh
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cRefresh
        MyBase._name = cRefresh
        MyBase._image = cRefresh
    End Sub
End Class
