﻿Public Class clsCommonDetailItem_SpinEdit
    Inherits clsCommonDetailItem

    Private _increment As Decimal = 1
    Public Property Increment As Decimal
        Set(value As Decimal)
            _increment = value
        End Set
        Get
            Return _increment
        End Get
    End Property

    Private _minValue As Decimal = 0
    Public Property MinValue As Decimal
        Set(value As Decimal)
            _minValue = value
        End Set
        Get
            Return _minValue
        End Get
    End Property

    Private _maxValue As Decimal = 0
    Public Property MaxValue As Decimal
        Set(value As Decimal)
            _maxValue = value
        End Set
        Get
            Return _maxValue
        End Get
    End Property
End Class
