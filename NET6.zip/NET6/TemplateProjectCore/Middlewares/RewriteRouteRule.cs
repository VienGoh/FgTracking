﻿using Microsoft.AspNetCore.Rewrite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TemplateProjectCore.Middlewares
{
    public class RewriteRouteRule
    {
        public static void ReWriteRequests(RewriteContext context)
        {
            var request = context.HttpContext.Request;
            if (request.Path.Value.Contains("//"))
            {
                string[] splitlist = request.Path.Value.Split("/");
                var newarray = splitlist.Where(s => !string.IsNullOrEmpty(s)).ToArray();
                var newpath = "";

                foreach (var item in newarray)
                {
                    newpath += "/" + item;
                }
                request.Path = newpath;
            }
        }
    }
}
