using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MMH.DataContextModel.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataModel.Entities
{
    public class Sample : BaseEntity
    {
        public int testA { get; set; }


    }
    public class SampleDetail : BaseEntity
    {
        public int SampleId { get; set; }
        [ForeignKey("SampleId")]
        public Sample testAAA { get; set; }
    }

    public class SampleChildADetail : BaseEntity
    {
        public int SampleId { get; set; }
        [ForeignKey("SampleId")]
        public Sample testAAA { get; set; }
    }



  public class TestTable1 : BaseEntity
  {
    public int property1 { get; set; }
    public String property2 { get; set; }
    public int property3 { get; set; }

    [ForeignKey("ChildRecordId")]
    public TestTable1 ChildRecord { get; set; }
    public int ChildRecordId { get; set; }
  }


  public class TestTable2 : BaseEntity
  {
    public int property1 { get; set; }
    public String property2 { get; set; }
    public int property3 { get; set; }

  }



}
