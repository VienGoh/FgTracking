﻿Imports System.Data.Odbc
Public Module modSQL
    Public Function GetConnectionString(ByVal Provider As String, ByVal Server As String, ByVal Database As String, ByVal SQLUser As String, ByVal SQLPass As String, ByVal Optional Port As String = "3306") As String
        Dim ConnStr As String = "Driver=" & Provider & "; Server=" & Server & "; Database=" & Database & "; User=" & SQLUser & "; Password=" & SQLPass & "; Port=" & Port & "; Option=3;"
        Return ConnStr
    End Function

    Public Sub ExecuteSQL(ByVal SQLQuery As String, ByVal ConnStr As String)
        Dim oConn As OdbcConnection = Nothing
        Dim oTrans As OdbcTransaction = Nothing
        Dim oCmd As OdbcCommand = Nothing

        Try
            oConn = New OdbcConnection(ConnStr)
            oConn.Open()
            oTrans = oConn.BeginTransaction()
            oCmd = New OdbcCommand(SQLQuery, oConn, oTrans)
            oCmd.ExecuteNonQuery()
            oTrans.Commit()

        Catch es As OdbcException
            oTrans.Rollback()
            Throw es

        Catch ex As Exception
            oTrans.Rollback()
            Throw ex
        Finally
            If oConn.State <> ConnectionState.Closed Then oConn.Close()
            oConn.Dispose()
            oCmd.Dispose()
            oTrans.Dispose()
        End Try
    End Sub

    Public Sub ExecuteSQLWithoutTransaction(ByVal SQLQuery As String, ByVal ConnStr As String, ByVal Optional TimeOut As Integer = 30)
        Dim oConn As OdbcConnection = Nothing
        Dim oCmd As OdbcCommand = Nothing

        Try
            oConn = New OdbcConnection(ConnStr)
            oConn.Open()
            oCmd = New OdbcCommand(SQLQuery, oConn)
            oCmd.CommandTimeout = TimeOut
            oCmd.ExecuteNonQuery()

        Catch es As OdbcException
            Throw es

        Catch ex As Exception
            Throw ex
        Finally
            If oConn.State <> ConnectionState.Closed Then oConn.Close()
            oConn.Dispose()
            oCmd.Dispose()
        End Try
    End Sub

    Public Function GetOneData(ByVal SQLQuery As String, ByVal DefaultValue As Object, ByVal ConnStr As String) As Object
        Dim oConn As OdbcConnection = Nothing
        Dim oCmd As OdbcCommand = Nothing
        Dim result As Object = Nothing

        Try
            oConn = New OdbcConnection(ConnStr)
            oConn.Open()
            oCmd = New OdbcCommand(SQLQuery, oConn)
            result = oCmd.ExecuteScalar()
            If IsNothing(result) Or IsDBNull(result) Then result = DefaultValue

        Catch es As OdbcException
            Throw es

        Catch ex As Exception
            Throw ex
        Finally
            If oConn.State <> ConnectionState.Closed Then oConn.Close()
            oConn.Dispose()
            oCmd.Dispose()
        End Try

        Return result

    End Function

    Public Function GetDataTable(ByVal SQLQuery As String, ByVal ConnStr As String, ByVal Optional TimeOut As Integer = 30, ByVal Optional SchemaOnly As Boolean = False) As DataTable
        Dim oConn As OdbcConnection = Nothing
        Dim oDt As New DataTable
        Dim oCmd As OdbcCommand = Nothing

        Try
            oConn = New OdbcConnection(ConnStr)
            oConn.Open()
            If SchemaOnly Then SQLQuery = SQLQuery & " WHERE 0"
            oCmd = New OdbcCommand(SQLQuery, oConn)
            oCmd.CommandTimeout = TimeOut

            If SchemaOnly Then
                oDt.Load(oCmd.ExecuteReader)
            Else
                Using dad As New OdbcDataAdapter(oCmd)
                    dad.Fill(oDt)
                    dad.Dispose()
                End Using
            End If

        Catch es As OdbcException
            Throw es

        Catch ex As Exception
            Throw ex
        Finally
            If oConn.State <> ConnectionState.Closed Then oConn.Close()
            oConn.Dispose()
            oCmd.Dispose()
        End Try

        Return oDt

    End Function

    Public Function HasRow(ByVal SQLQuery As String, ByVal ConnStr As String) As Boolean
        Dim oConn As OdbcConnection = Nothing
        Dim oCmd As OdbcCommand = Nothing
        Dim result As Boolean = False

        Try
            oConn = New OdbcConnection(ConnStr)
            oConn.Open()
            oCmd = New OdbcCommand(SQLQuery, oConn)

            Dim reader As OdbcDataReader = oCmd.ExecuteReader()
            If reader.Read Then result = True

        Catch es As OdbcException
            Throw es

        Catch ex As Exception
            Throw ex
        Finally
            If oConn.State <> ConnectionState.Closed Then oConn.Close()
            oConn.Dispose()
            oCmd.Dispose()
        End Try

        Return result
    End Function

    Public Function IsNulls(ByVal CheckValue As Object, DefaultValue As Object) As Object
        If IsNothing(CheckValue) Then
            Return DefaultValue
        ElseIf IsDBNull(CheckValue) Then
            Return DefaultValue
        Else
            Return CheckValue
        End If
    End Function

    Public Function IsNullsOrBlank(ByVal CheckValue As Object, DefaultValue As Object) As Object
        If IsNothing(CheckValue) Then
            Return DefaultValue
        ElseIf IsDBNull(CheckValue) Then
            Return DefaultValue
        ElseIf CheckValue.ToString = "" Then
            Return DefaultValue
        Else
            Return CheckValue
        End If
    End Function

    Public Function StrSQL(ByVal oValue As String) As String
        Return "'" & oValue & "'"
    End Function

    Public Function SQLDate(ByVal oDate As Date) As String
        Return "'" & oDate.Year & "/" & oDate.Month & "/" & oDate.Day & "'"
    End Function

    Public Function SQLDateTime(ByVal oDate As Date) As String
        Return "'" & oDate.Year & "/" & oDate.Month & "/" & oDate.Day & " " & oDate.Hour & ":" & oDate.Minute & ":" & oDate.Second & "'"
    End Function

End Module
