﻿Public Class clsCommonDetailItem_MemoExEdit
    Inherits clsCommonDetailItem

End Class
