﻿Imports System.Drawing.Printing
Imports System.Text.RegularExpressions
Imports DevExpress.Utils
Imports DevExpress.XtraEditors
Imports DevExpress.XtraGrid
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraPrinting
Imports DevExpress.XtraPrinting.Preview
Imports DevExpress.XtraPrintingLinks

Public Class frmPrintPreview

    Public ReportHeader As String
    Public DataSource As DataTable
    Public GridCustomFormat As Dictionary(Of String, String)
    Public GridConditionalFormat As Dictionary(Of String, FormatConditionRuleExpression)
    Public GridSummaryColumn As List(Of GridColumnSummaryItem)
    Public IsLandscape As Boolean = False
    Public PaperKind As PaperKind = PaperKind.A4
    Public AddonGrid() As GridControl

    Private Sub btnPrintPreview_Click(sender As Object, e As EventArgs) Handles btnPrintPreview.Click
        If Not IsDataSourceHasRow() Then Exit Sub

        Dim fLeftColumn As String = "Pages: [Page # of Pages #]"
        Dim fMiddleColumn As String = "User: [User Name]"
        Dim fRightColumn As String = "Date: [Date Printed]"

        ' Create a PageHeaderFooter object and initializing it with
        ' the link's PageHeaderFooter.
        Dim printingSystem1 As PrintingSystem = New PrintingSystem()
        Dim printableComponentLink1 As PrintableComponentLink = New PrintableComponentLink()
        'Dim documentViewer1 As DocumentViewer = New DocumentViewer()
        Dim compositeLink1 As CompositeLink = New CompositeLink()

        ' Add the link to the printing system's collection of links.
        'printingSystem1.Links.AddRange(New Object() {printableComponentLink1})

        ' Assign the printing system to the document viewer.
        'documentViewer1.PrintingSystem = printingSystem1

        Dim phf As PageHeaderFooter =
        TryCast(compositeLink1.PageHeaderFooter, PageHeaderFooter)

        ' Clear the PageHeaderFooter's contents.
        phf.Header.Content.Clear()
        phf.Footer.Content.Clear()

        ' Add custom information to the link's header.
        phf.Footer.Content.AddRange(New String() _
        {fLeftColumn, fMiddleColumn, fRightColumn})

        phf.Header.Content.AddRange({"", ReportHeader.ToUpper, ""})
        phf.Header.Font = New Font("Microsoft Sans Serif", 9, FontStyle.Bold)
        phf.Header.LineAlignment = BrickAlignment.Far

        GridView1.BeginUpdate()
        GridView1.ColumnPanelRowHeight = 50

        GridView1.AppearancePrint.HeaderPanel.TextOptions.WordWrap = WordWrap.Wrap
        printableComponentLink1.Component = GridControl1

        With compositeLink1
            .PrintingSystem = printingSystem1
            .Margins = New System.Drawing.Printing.Margins(50, 50, 50, 50)
            .Landscape = IsLandscape
            .PaperKind = PaperKind
            .Links.Add(printableComponentLink1)
            .BreakSpace = 100

            'tambah addon gridcontrol
            If AddonGrid IsNot Nothing Then
                For Each gc As GridControl In AddonGrid
                    Dim pcl As PrintableComponentLink = New PrintableComponentLink()
                    pcl.Component = gc
                    compositeLink1.Links.Add(pcl)
                Next
            End If

            .CreateDocument()
            .ShowRibbonPreview(GridControl1.LookAndFeel)
        End With

        GridView1.ColumnPanelRowHeight = -1
        GridView1.EndUpdate()

    End Sub

    Private Sub frmPrintPreview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SettingGridControl()
    End Sub

    Private Sub SettingGridControl()
        If Not IsDataSourceHasRow() Then Exit Sub

        GridControl1.DataSource = DataSource
        lblRowCount.Text = If(DataSource.Rows.Count > 0, DataSource.Rows.Count & " Rows", "No Row")
        GridView1.BestFitColumns()

        If DataSource.Rows.Count > 0 Then
            For i As Byte = 0 To DataSource.Columns.Count - 1
                If GridCustomFormat IsNot Nothing Then
                    Dim formatString As String = ""
                    If GridCustomFormat.TryGetValue(DataSource.Columns(i).ColumnName, formatString) Then
                        GridView1.Columns(i).DisplayFormat.FormatType = FormatType.Custom
                        GridView1.Columns(i).DisplayFormat.FormatString = formatString
                    End If
                End If

                If GridConditionalFormat IsNot Nothing Then
                    Dim conditionalFormat As New FormatConditionRuleExpression
                    If GridConditionalFormat.TryGetValue(DataSource.Columns(i).Caption, conditionalFormat) Then
                        Dim gridFormatRule As New GridFormatRule
                        gridFormatRule.Name = DataSource.Columns(i).Caption
                        gridFormatRule.Column = GridView1.Columns(DataSource.Columns(i).Caption)
                        gridFormatRule.ColumnApplyTo = GridView1.Columns(DataSource.Columns(i).Caption)
                        gridFormatRule.Rule = conditionalFormat
                        GridView1.FormatRules.Add(gridFormatRule)
                    End If
                End If

                Dim colCaption As String = DataSource.Columns(i).Caption.Replace("_", " ")
                colCaption = Regex.Replace(colCaption, "([a-z])([A-Z])", "$1 $2").ToUpper
                TryCast(GridControl1.MainView, GridView).Columns(i).Caption = colCaption
            Next

            If GridSummaryColumn IsNot Nothing Then
                For Each colSum As GridColumnSummaryItem In GridSummaryColumn
                    GridView1.Columns(colSum.FieldName).Summary.Add(colSum)
                Next
            End If

        End If

        GridView1.BestFitColumns()
    End Sub

    Private Function IsDataSourceHasRow() As Boolean
        IsDataSourceHasRow = True
        If IsNothing(DataSource) Then Return False
        If DataSource.Rows.Count = 0 Then Return False
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
