﻿Public Class clsCallType_TemplateView
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cView
        MyBase._name = cView
        MyBase._image = cView
    End Sub
End Class
