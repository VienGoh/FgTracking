﻿Public Class clsCallType_TemplateNew
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cNew
        MyBase._name = cNew
        MyBase._image = cNew
    End Sub

End Class
