﻿Imports System.Reflection
Imports CrystalDecisions.CrystalReports.Engine

Public Class frmCrystalReport

    Private _objReport As Object
    Public WriteOnly Property ObjReport As Object
        Set(value As Object)
            _objReport = value
        End Set
    End Property

    Private _dataSource As DataTable
    Public WriteOnly Property DataSource As DataTable
        Set(value As DataTable)
            _dataSource = value
        End Set
    End Property

    Private _showCopyButton As Boolean = True
    Public WriteOnly Property ShowCopyButton As Boolean
        Set(value As Boolean)
            _showCopyButton = value
        End Set
    End Property

    Private _showExportButton As Boolean = True
    Public WriteOnly Property ShowExportButton As Boolean
        Set(value As Boolean)
            _showExportButton = value
        End Set
    End Property

    Private _showPrintButton As Boolean = True
    Public WriteOnly Property ShowPrintButton As Boolean
        Set(value As Boolean)
            _showPrintButton = value
        End Set
    End Property

    Private _reportParameter As List(Of Object)
    Public WriteOnly Property ReportParameter
        Set(value)
            _reportParameter = value
        End Set
    End Property

    Private Sub frmCrystalReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim objRpt As ReportDocument = _objReport

        With objRpt
            .SetDataSource(_dataSource)
            If _reportParameter IsNot Nothing Then
                For i As Integer = 0 To _reportParameter.Count - 1
                    .SetParameterValue(i, _reportParameter(i))
                Next
            End If
        End With

        With CrystalReportViewer1
            .ShowCopyButton = _showCopyButton
            .ShowExportButton = _showExportButton
            .ShowPrintButton = _showPrintButton
            .ReportSource = objRpt
        End With

    End Sub
End Class