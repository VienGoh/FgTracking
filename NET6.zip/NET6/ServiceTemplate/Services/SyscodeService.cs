using DataModel.Contexts;
using DataModel.Entities;
using MMH.DataContextModel.Entities;
using MMH.HelperService.Interfaces.Repositories;
using MMH.HelperService.Interfaces.Services;
using MMH.HelperService.Services;
using MMH.HelperService.Specifications;
using ServiceTemplate.Interfaces.Repo;
using ServiceTemplate.Interfaces.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using MMHContext = MMH.DataContextModel.Contexts.dbContext;

namespace ServiceTemplate.Services
{
  public class SysCodeService : BaseService<MMHContext, SysCode>, ISysCodeService
  {
    private readonly MMHContext _context;
    public SysCodeService(IBaseRepository<MMHContext, SysCode> repo, MMHContext mMHContext) : base(repo)
    {
       _context = mMHContext;
    }


    public List<SysCode> GetSysCodes(string type, int? buSystemId = null)
    {
      SysCode tempSysCodeT1 = this.GetByIdWithNoTrack(1);  //retrive current service table with record id =1 (without EF Tracking)
      tempSysCodeT1.Name ="DUMMMMY";
      _context.SaveChanges();       // WONT save into the database


      SysCode tempSysCodeT2 = this.GetById(1);  //retrive current service table with record id =1 (with EF Tracking)
      tempSysCodeT2.Name = "DUMMMMY";
      _context.SaveChanges();       // WILL save into the database


      SysCode tempSysCode2 = this.GetById(1);  //retrive current service table with record id =1 (with EF Tracking)
      List<SysCode> result1 = repo.GetByConditionAsQueryableWithDisabledRecord(x => x.Type == type && !x.Disabled && x.BUSystemId == buSystemId).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
      List<SysCode> result2 = repo.GetByConditionAsQueryable(x => x.Type == type && !x.Disabled && x.BUSystemId == buSystemId).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
      return result2;
    }

    public SysCode GetSysCode(string type, string code, int? buSystemId = null)
    {
      var spec = new BaseSpecification<SysCode>(x => x.Type == type && x.Code == code && !x.Disabled && x.BUSystemId == buSystemId);
      return GetSysCode(spec).FirstOrDefault();
    }

    private List<SysCode> GetSysCode(BaseSpecification<SysCode> spec)
    {
      return this.repo.Find(spec).ToList();
    }


  }


}
