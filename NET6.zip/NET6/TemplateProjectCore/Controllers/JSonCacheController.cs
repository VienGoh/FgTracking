using DataModel.Contexts;
using DataModel.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MMH.HelperController.Utilities;
using ServiceTemplate.Interfaces.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;
using Telerik.Barcode;
using MMH.DataContextModel.Contexts;

namespace TemplateProjectCore.Controllers
{
  //[Authorize]
  [ApiController]
  //[Route("api/[controller]")]
  public class JSonCacheController : BaseController<LocalDbContext, Sample>
  {
    public ISampleService _svc;
    public JSonCacheController(ISampleService svc) : base(svc)
    {
      _svc = svc;
    }

    public override IActionResult Get(int id)
    {
      if (HttpContext.Request.Headers.TryGetValue("Uniqueidentifier", out var headerValue))
      {
        string aaa = headerValue;
        // Use the headerValue here or perform any other logic based on the header value
        //return Ok($"Value of Your-Header-Name: {headerValue}");
      }


      LocalDbContext xxxvv = null;
      try
      {
        var optionsBuilder = new DbContextOptionsBuilder<LocalDbContext>();
        optionsBuilder.UseSqlServer(@"Data Source=(localdb)\ProjectModels; Database = zzzz; user id = piaw; password = piaw1212; connect timeout = 30; MultipleActiveResultSets = True;App=EntityFramework");
        xxxvv = new LocalDbContext(optionsBuilder.Options);
      }
      catch (Exception ex)
      {

      }
      Thread.Sleep(3 * 1000);
      Sample obj = xxxvv.Samples.FirstOrDefault(x => x.Id == id);

      //object obj = svc.GetByIdAsObject(id);
      if (obj == null)
      {
        return NotFound();
      }
      return Ok(obj);

      Thread.Sleep(3 * 1000);
      List<int> sss = new List<int>();
      sss.Add(222);
      sss.Add(333);
      sss.Add(444);
      sss.Add(555);
      return Ok(sss);
    }

    public override IActionResult Put([FromRoute] int id, [FromBody] Sample obj)
    {

      return base.Put(id, obj);

      LocalDbContext xxxvv = null;
      try
      {
        var optionsBuilder = new DbContextOptionsBuilder<LocalDbContext>();
        optionsBuilder.UseSqlServer(@"Data Source=(localdb)\ProjectModels; Database = zzzz; user id = piaw; password = piaw1212; connect timeout = 30; MultipleActiveResultSets = True;App=EntityFramework");
        xxxvv = new LocalDbContext(optionsBuilder.Options);
      }
      catch (Exception ex)
      {

      }
      Thread.Sleep(3 * 1000);
      var modifiedEntries = xxxvv.ChangeTracker.Entries<Sample>().Where(e => e.State == EntityState.Modified);
      Sample original = xxxvv.Samples.FirstOrDefault(x => x.Id == obj.Id);
      original.ModByUserDisplayName = "niamamama";
      original.testA = obj.testA;
      xxxvv.Set<Sample>().Update(original);
      xxxvv.SaveChanges();
      var modifiedEntries222 = xxxvv.ChangeTracker.Entries<Sample>().Where(e => e.State == EntityState.Modified);

      return Ok(xxxvv.Samples.FirstOrDefault(x => x.Id == obj.Id));
    }

    public override IActionResult Post(Sample obj)
    {
      return base.Post(obj);
    }

    [HttpGet("TestEFDynamicQuery")]
    public IActionResult TestEFDynamicQuery()
    {

      var ggggggg=_svc.TestEFDynamicQuery();




      return Ok();
    }

  } 


}
