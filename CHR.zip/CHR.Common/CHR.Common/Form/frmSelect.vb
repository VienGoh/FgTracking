﻿Public Class frmSelect

    Private _dt As DataTable
    Public WriteOnly Property DataSource As DataTable
        Set(value As DataTable)
            _dt = value
        End Set
    End Property

    Private _result As DataTable
    Public ReadOnly Property Result As DataTable
        Get
            Return _result
        End Get
    End Property

    Private _isMultiSelect As Boolean = True
    Public WriteOnly Property IsMultiSelect As Boolean
        Set(value As Boolean)
            _isMultiSelect = value
        End Set
    End Property

    Private _dockToolStrip As DockStyle = DockStyle.Top
    Public Property DockToolStrip As DockStyle
        Set(value As DockStyle)
            _dockToolStrip = value
        End Set
        Get
            Return _dockToolStrip
        End Get
    End Property



    Private Sub frmMultipleSelect_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolStrip1.Dock = DockToolStrip
        GridView1.OptionsSelection.MultiSelect = _isMultiSelect
        GridControl1.DataSource = _dt
        GridView1.BestFitColumns()
        _result = _dt.Copy
        _result.Clear()
    End Sub

    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click, GridControl1.MouseDoubleClick
        'For Each rowindex As Integer In GridView1.GetSelectedRows()
        '    Dim str As String = GridView1.GetRowCellValue(rowindex, _dt.Columns(0).Caption)
        '    '_result = _result & If(_result = "", str, "," & str)
        'Next

        Dim selectedRowHandles As Int32() = GridView1.GetSelectedRows()
        For I = 0 To selectedRowHandles.Length - 1
            Dim selectedRowHandle As Int32 = selectedRowHandles(I)
            If (selectedRowHandle >= 0) Then
                _result.ImportRow(GridView1.GetDataRow(selectedRowHandle))
            End If
        Next

        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

End Class