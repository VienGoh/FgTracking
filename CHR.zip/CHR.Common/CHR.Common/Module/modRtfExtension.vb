﻿Imports System.Runtime.CompilerServices

Module modRtfExtension
    <Extension()>
    Public Function ToRtf(s As String) As String
        Return "{\rtf1\ansi{\fonttbl{\f0\fnil\fcharset0 Tahoma;}{\f1\fnil\fcharset0 Calibri;}}" + s + "}"
    End Function

    <Extension()>
    Public Function ToBold(s As String) As String
        Return String.Format("\qc\fs16\b {0}\b0 ", s)
    End Function

End Module
