using DataModel.Contexts;
using Infrastructure.Authorization.Extensions;
using Infrastructure.SignalR.Extensions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using MMH.DataContextModel.Extensions;
using MMH.HelperService.Extensions;
using MMH.HelperUtilities.Extensions;
using MMH.HelperUtilities.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using ServiceTemplate.Interfaces.Repo;
using ServiceTemplate.Interfaces.Service;
using ServiceTemplate.Repositories;
using ServiceTemplate.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using TemplateProjectCore.Extensions;
using TemplateProjectCore.Middlewares;

namespace TemplateProjectCore
{
  public class Startup
  {
    public Startup(IWebHostEnvironment env)
    {
      Configuration = new ConfigurationBuilder()
          .SetBasePath(env.ContentRootPath)
          .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
          .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
          .AddEnvironmentVariables()
          .Build();
    }

    public IConfiguration Configuration { get; }

    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
      services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
      services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
      .AddJwtBearer(option =>
      {
        option.ClaimsIssuer = "OAuth2";
        option.TokenValidationParameters = new TokenValidationParameters
        {
          ValidateIssuer = true,
          ValidateAudience = true,
          ValidateLifetime = true,
          ValidateIssuerSigningKey = true,
          ValidIssuer = "OAuth2",
          ValidAudience = "all",
          IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration[key: "jwt:Jwt_SecretKey"])),
          ClockSkew = TimeSpan.Zero
        };
      }
      );

      // Inject IPrincipal
      services.AddHttpContextAccessor();
      services.AddScoped<IPrincipal>(provider => provider.GetService<IHttpContextAccessor>().HttpContext.User);
      services.AddMvc(options =>
      {
        options.Filters.Add(new ApiLoggingInfoFilter(services.BuildServiceProvider().CreateScope().ServiceProvider));
        options.Filters.Add(new ApiExceptionFilter());
      });

      //services.AddHostedService<ActionExecutionBackgroundService>();
      services.AddE1Authorization<Startup>(Configuration);
      services.AddOAuthEndPoint(Configuration);
      services.AddHelperServices(Configuration);
      services.AddDbContextModel<LocalDbContext>(Configuration);
      services.AddControllers().AddNewtonsoftJson(options =>
      {
        options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
        options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
        options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind;
        //avoid camel case names by default
        options.SerializerSettings.ContractResolver = new DefaultContractResolver();
      });
      services.AddControllers();
      services.AddLocalServices();
      services.AddSwaggerGen(c =>
      {
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "TemplateProjectCore", Version = "v1" });
      });

      services.AddHubConnection(Configuration);
      RegisterDIServices(services);
      services.AddIIIIIIIIServices();
    }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
      if (env.IsDevelopment())
      {
        // code to be executed in SIT environment 

      }
      else if (env.IsEnvironment("SIT"))
      {
        // code to be executed in SIT environment 

      }
      else if (env.IsEnvironment("QA"))
      {
        // code to be executed in QA environment 

      }
      else if (env.IsEnvironment("UAT"))
      {
        // code to be executed in UAT environment 

      }
      else if (env.IsProduction())
      {
        // code to be executed in Production environment 

      }
      else
      {

      }

      // code to be executed in development environment 
      app.UseDeveloperExceptionPage();
      app.UseSwagger();
      app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "TemplateProjectCore"));

      app.UseRewriter(new RewriteOptions().Add(RewriteRouteRule.ReWriteRequests));

      app.UseHttpsRedirection();

      app.UseStaticFiles();
      app.UseRouting();

      app.UseCors(x => x.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
      app.UseAuthentication();
      app.UseMiddleware<MessageHandlerInterceptor>();
      app.UseAuthorization();
      app.UseE1Authorization();
      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllers();
        endpoints.MapControllerRoute(
                  name: "DefaultApi",
                  pattern: "api/{controller}/{id}");
      });
      app.UseDataContextModel();
      app.UseHelperUtilities();
      app.UseHelperServices();

      // Reponse a message when solution run in debug. 
      app.Run(async (context) =>
      {
        await context.Response.WriteAsync("WebApi Page");
      });

      LocalDbContext.ValidateDatabaseModel = true;
    }

    public void RegisterDIServices(IServiceCollection services)
    {
      services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

      // #region "Custom Service"
      services.AddScoped(typeof(ISampleService), typeof(SampleService));
      services.AddScoped(typeof(ISampleDetailService), typeof(SampleDetailService));
      services.AddScoped(typeof(ISysCodeService), typeof(SysCodeService));

      // #endregion 


      // #region "Custom Repository"
      services.AddScoped(typeof(ISampleRepository), typeof(SampleRepository));
      services.AddScoped(typeof(ISampleDetailRepository), typeof(SampleDetailRepository));

      // #endregion 
    }

  }
}
