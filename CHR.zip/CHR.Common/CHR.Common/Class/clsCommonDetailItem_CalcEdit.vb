﻿Public Class clsCommonDetailItem_CalcEdit
    Inherits clsCommonDetailItem

    Private _precision As Integer = 0
    Public Property Precision As Integer
        Set(value As Integer)
            _precision = value
        End Set
        Get
            Return _precision
        End Get
    End Property
End Class
