﻿using System;

namespace ServiceTemplate
{
    public class Class1
    {
    }
}
