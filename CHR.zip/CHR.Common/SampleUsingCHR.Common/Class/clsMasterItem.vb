﻿Imports System.Drawing.Printing
Imports CHR.Common
Imports DevExpress.XtraEditors
Imports DevExpress.XtraGrid

Public Class clsMasterItem
    Implements iclsList

    Dim dt As DataTable
    Dim conStr As String = GetConnectionString(My.Settings.Server, My.Settings.Database, My.Settings.AppID, False, "sa", "ipiserver!234")

    Dim itemCode As String
    Dim itemName As String
    Dim itemType As String
    Dim itemQty As Decimal
    Dim itemExpiryDate As Date
    Dim itemDescription As String
    Dim itemUnitCost As Decimal
    Dim itemBaseUOM As String
    Dim itemMinOrderQty As Decimal
    Dim itemMaxOrderQty As Decimal


    Public Function Action(DataRow As DataRow, ActionType As String) As Boolean Implements iclsList.Action
        'Note : jika function ini return True, maka grid akan di refresh
        Action = False

        If ActionType = cRefresh Then
            Action = True
            Exit Function
        End If

        If Not ActionType = cNew And IsNothing(DataRow) Then Exit Function

        'untuk print gridview tanpa melalui crystal report
        If ActionType = cPrint Then
            Dim fPP As New frmPrintPreview With {
                .PaperKind = PaperKind.A4,
                .DataSource = dt,
                .GridCustomFormat = CustomFormat(),
                .GridConditionalFormat = ConditionalFormat(),
                .ReportHeader = "Master Item",
                .IsLandscape = True,
                .Text = "Print Master Item"}
            fPP.ShowDialog()
        ElseIf ActionType = cReport Then
            'untuk tampil crystal report
            Dim fCR As New frmCrystalReport With {
                .ObjReport = New RPT_Item,
                .DataSource = dt}
            fCR.ShowDialog()
        Else
            'case view, new, edit, delete
            'l_Dt untuk data nya, sedangkan l_Schema untuk struktur nya (sudah termasuk maxlength, jadi tidak perlu set lagi)
            Dim l_Dt As DataTable = dt.Copy
            Dim l_schema As DataTable = GetDataTable("Select * FROM TBL_Item", conStr, SchemaOnly:=True)
            l_Dt.Clear()
            l_schema.Clear()

            If ActionType = cNew Then
                l_Dt.Rows.Add()
            Else
                l_Dt.ImportRow(DataRow)
            End If

            Dim l As New List(Of Object)
            'Note : untuk kolom2 yang ingin diedit, harus ditambahkan ke list ini
            'Note : untuk kolom2 yang hanya readonly, tidak perlu di tambahkan ke list ini
            'Note : untuk kolom2 yang harus diisi, gunakan property .AllowNull = False dan .AllowTrimEmptyString = False
            l.Add(New clsCommonDetailItem_GridLookup With {
                  .ConnectionString = GetConnectionString(My.Settings.Server, "IPI_LIVE", My.Settings.AppID, False, "sa", "ipiserver!234"),
                  .SqlQuery = "SELECT TOP 1000 * FROM [PT Industri Pembungkus Intl_$Item] WHERE [No_] LIKE 'CBFG%'",
                  .LookupAndAffectedRow = {{"ItemCode", "No_"}, {"ItemUnitCost", "Unit Price"}, {"ItemDescription", "Description"}, {"ItemBaseUOM", "Base Unit of Measure"}},
                  .RowName = "ItemCode",
                  .RowFriendlyName = "Item Code",
                  .RowDescription = "Item Code",
                  .AllowNull = False,
                  .AllowTrimEmptyString = False,
                  .IsReadOnly = ActionType = cEdit})

            'untuk item isian textbox atau boolean (varchar atau bit)
            l.Add(New clsCommonDetailItem With {.RowName = "ItemName",
                  .RowFriendlyName = "Item Name",
                  .RowDescription = "Item Name",
                  .AllowNull = False,
                  .AllowTrimEmptyString = False})

            'untuk item isian textbox multiline
            l.Add(New clsCommonDetailItem_MemoExEdit With {.RowName = "ItemDescription",
                  .RowFriendlyName = "Item Description",
                  .RowDescription = "Item Description"})

            'untuk item combobox
            l.Add(New clsCommonDetailItem_ComboBoxEdit With {.RowName = "ItemType",
                  .RowFriendlyName = "Item Type",
                  .RowDescription = "Item Type",
                  .Items = {"Kotak Kardus", "Offset", "Kemasan makanan", "Digital Printing"},
                  .AllowNull = False,
                  .AllowTrimEmptyString = False})

            'untuk item calculator
            l.Add(New clsCommonDetailItem_CalcEdit With {
                  .RowName = "ItemUnitCost",
                  .RowFriendlyName = "Item Unit Cost",
                  .RowDescription = "Item Unit Cost",
                  .Precision = 2,
                  .AllowNull = False,
                  .AllowTrimEmptyString = False})

            'untuk item radio
            l.Add(New clsCommonDetailItem_RadioGroup With {.RowName = "ItemBaseUOM",
                  .RowFriendlyName = "Item Base UOM",
                  .RowDescription = "Item Base UOM",
                  .Items = {"PCS", "GR", "KG", "TON"},
                  .AllowNull = False,
                  .AllowTrimEmptyString = False})

            'untuk item tanggal, jika mau tampilkan jam, set ShowTime = True, jika tidak mau tampilkan jam, tidak perlu set ShowTime karena default value nya adalah False
            l.Add(New clsCommonDetailItem_DateEdit With {.RowName = "ItemExpiryDate",
                  .RowFriendlyName = "Item Expiry Date",
                  .RowDescription = "Expiry date of item",
                  .DateFormat = "MM/dd/yyyy",
                  .ShowTime = True,
                  .AllowNull = False,
                  .AllowTrimEmptyString = False})

            'untuk item seperti numeric up down
            l.Add(New clsCommonDetailItem_SpinEdit With {.RowName = "ItemQty",
                  .RowFriendlyName = "Item Qty",
                  .RowDescription = "Item Qty",
                  .Increment = 1,
                  .MinValue = 0,
                  .MaxValue = 1000000,
                  .AllowNull = False,
                  .AllowTrimEmptyString = False})

            'untuk item seperti numeric up down
            l.Add(New clsCommonDetailItem_SpinEdit With {.RowName = "ItemMinOrderQty",
                  .RowFriendlyName = "Item Min Order Qty",
                  .RowDescription = "Minimum Order Quantity",
                  .Increment = 1,
                  .MinValue = 0,
                  .MaxValue = 1000000,
                  .AllowNull = False,
                  .AllowTrimEmptyString = False})

            'untuk item seperti numeric up down
            l.Add(New clsCommonDetailItem_SpinEdit With {.RowName = "ItemMaxOrderQty",
            .RowFriendlyName = "Item Max Order Qty",
            .RowDescription = "Maximum Order Quantity",
            .Increment = 1,
            .MinValue = 0,
            .MaxValue = 1000000,
            .AllowNull = False,
            .AllowTrimEmptyString = False})

            'l.Add(New clsCommonDetailItem_TimeEdit With {.RowName = "ItemMaxOrderQty",
            '.RowFriendlyName = "Item Max Order Qty",
            '.RowDescription = "Maximum Order Quantity",
            '.TimeFormat = "HH:mm:ss",
            '.AllowNull = False,
            '.AllowTrimEmptyString = False})

            Dim f As New frmCommonDetail With {.Text = ActionType,
                                                .DataSource = l_Dt,
                                                .Schema = l_schema,
                                                .ListCustomItem = l,
                                                .ButtonSaveText = "Save",
                                                .IsForView = ActionType = cView,
                                                .IsForDelete = ActionType = cDelete}

            Dim dialogResult As DialogResult = Nothing
            Try
                Do
                    dialogResult = f.ShowDialog
                    If dialogResult = DialogResult.OK Then
                        Action = Save(f.Result, ActionType)
                    End If
                Loop Until Action Or Not dialogResult
            Catch ex As Exception
                mbError(ex.ToString)
            End Try

            f.Dispose()
        End If

    End Function

    Public Function CallTypeList() As List(Of iclsCallType) Implements iclsList.CallTypeList
        Dim l As New List(Of iclsCallType)
        l.Add(New clsCallType_TemplateView)
        l.Add(New clsCallType_TemplateNew)
        l.Add(New clsCallType_TempateEdit)
        l.Add(New clsCallType_TempateDelete)
        l.Add(New clsCallType_TempateRefresh)
        l.Add(New clsCallType_TemplateReport)
        l.Add(New clsCallType_TemplatePrint)
        Return l
    End Function

    Public Function ColumnNumToFreeze() As String Implements iclsList.ColumnNumToFreeze
        'artinya kolom ke 0-1 di freeze, jika tidak ada kolom yg mau di freeze return Nothing saja
        Return "0-1"
    End Function

    Public Function ConditionalFormat() As Dictionary(Of String, FormatConditionRuleExpression) Implements iclsList.ConditionalFormat
        'jika tidak ada kolom yg mau di conditional format return Nothing saja
        Dim cf As New Dictionary(Of String, FormatConditionRuleExpression)

        Dim re As New FormatConditionRuleExpression
        With re
            .Expression = "ItemQty > 100"
            .Appearance.ForeColor = Color.Red
            cf.Add("ItemQty", re)
        End With

        re = New FormatConditionRuleExpression
        With re
            .Expression = "ItemMinOrderQty <= 0"
            .Appearance.ForeColor = Color.Blue
            cf.Add("ItemMinOrderQty", re)
        End With

        Return cf
    End Function

    Public Function CustomFormat() As Dictionary(Of String, String) Implements iclsList.CustomFormat
        'jika tidak ada kolom yg mau di custom format return Nothing saja
        Dim cf As New Dictionary(Of String, String)
        cf.Add("ItemQty", "N0")
        cf.Add("ItemExpiryDate", "yyyy-MM-dd")
        cf.Add("ItemBaseUOM", "N0")
        cf.Add("ItemMinOrderQty", "N0")
        cf.Add("ItemMaxOrderQty", "N0")
        Return cf
    End Function

    Public Function RefreshData() As DataTable Implements iclsList.RefreshData
        'Note : Usahakan jangan pakai select * from karena lebih lambat dibandingkan select kolom1, kolom2, ... from...
        dt = GetDataTable("Select ItemCode, ItemName, ItemType, ItemQty, ItemExpiryDate,  ItemDescription, " &
                          "ItemUnitCost, ItemBaseUOM, ItemMinOrderQty, ItemMaxOrderQty FROM TBL_Item",
                          conStr)
        Return dt
    End Function

    Private Function Save(DataRow As DataRow, ActionType As String) As Boolean
        Save = False

        ReadData(DataRow)
        If IsValid(DataRow, ActionType) Then

            Dim SQL As String = ""
            If ActionType = cNew Then
                SQL = String.Format(<![CDATA[INSERT INTO TBL_Item VALUES ({0},{1},{2},{3},{4},{5},{6},{7},{8},{9})]]>.Value,
                                    StrSQL(itemCode), StrSQL(itemName), StrSQL(itemType), itemQty, SQLDate(itemExpiryDate),
                                    StrSQL(itemDescription), itemUnitCost, StrSQL(itemBaseUOM), itemMinOrderQty, itemMaxOrderQty)
            ElseIf ActionType = cEdit Then
                SQL = String.Format(<![CDATA[UPDATE TBL_Item SET ItemName={1}, ItemType={2}, ItemQty={3}, ItemExpiryDate={4}, 
                                    ItemDescription={5}, ItemUnitCost={6}, ItemBaseUOM={7}, ItemMinOrderQty={8}, ItemMaxOrderQty={9}
                                    WHERE ItemCode={0}]]>.Value,
                                    StrSQL(itemCode), StrSQL(itemName), StrSQL(itemType), itemQty, SQLDate(itemExpiryDate),
                                    StrSQL(itemDescription), itemUnitCost, StrSQL(itemBaseUOM), itemMinOrderQty, itemMaxOrderQty)
            ElseIf ActionType = cDelete Then
                SQL = String.Format(<![CDATA[DELETE FROM TBL_Item WHERE ItemCode={0}]]>.Value, StrSQL(itemCode))
            End If

            ExecuteSQL(SQL, conStr)

            Save = True
            mbInfo("Data save successfully.")
        End If

    End Function

    Private Function IsValid(DataRow As DataRow, ActionType As String) As Boolean
        'untuk validasi data
        If ActionType = cNew Then
            If HasRow("SELECT * FROM TBL_Item WHERE ItemCode = " & StrSQL(itemCode), conStr) Then Throw New Exception("validasi new.")
        ElseIf ActionType = cEdit Then
            If HasRow("SELECT * FROM TBL_Item WHERE ItemCode = " & StrSQL(itemCode) & " AND ISNULL(ItemName,'') = ''", conStr) Then Throw New Exception("validasi edit.")
        ElseIf ActionType = cDelete Then
            If HasRow("SELECT * FROM TBL_Item WHERE ItemCode = " & StrSQL(itemCode) & " AND ISNULL(ItemName,'') <> ''", conStr) Then Throw New Exception("validasi delete.")
        End If
        IsValid = True
    End Function

    Private Sub ReadData(ByVal DataRow As DataRow)
        With DataRow
            itemCode = .Item("ItemCode")
            itemName = .Item("ItemName")
            itemType = .Item("ItemType")
            itemQty = .Item("ItemQty")
            itemExpiryDate = .Item("ItemExpiryDate")
            itemDescription = IsNulls(.Item("ItemDescription"), Nothing)
            itemUnitCost = .Item("ItemUnitCost")
            itemBaseUOM = .Item("ItemBaseUOM")
            itemMinOrderQty = .Item("ItemMinOrderQty")
            itemMaxOrderQty = .Item("ItemMaxOrderQty")
        End With
    End Sub

    Public Function AddonText() As String Implements iclsList.AddonText
        Return ""
    End Function

    Public Function SummaryColumn() As List(Of GridColumnSummaryItem) Implements iclsList.SummaryColumn
        Return Nothing
    End Function
    Public Function GroupSum() As List(Of GridGroupSummaryItem) Implements iclsList.GroupSum
        Throw New NotImplementedException()
    End Function

    Public Function FontGridView() As Object Implements iclsList.FontGridView
        'untuk mengubah ukuran font pada grid view tinggal mengubah comment return dibawah menjadi aktif dan nonaktifkan return nothing
        'Return New System.Drawing.Font("Tahoma", 18.0!)
        Return Nothing
    End Function
End Class
