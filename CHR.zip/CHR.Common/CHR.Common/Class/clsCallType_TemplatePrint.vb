﻿Public Class clsCallType_TemplatePrint
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cPrint
        MyBase._name = cPrint
        MyBase._image = cPrinter
    End Sub
End Class
