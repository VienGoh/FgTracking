﻿Public Class clsCommonDetailItem_LookupEdit
    Inherits clsCommonDetailItem

    Private _connectionString As String
    Public Property ConnectionString As String
        Set(value As String)
            _connectionString = value
        End Set
        Get
            Return _connectionString
        End Get
    End Property

    Private _sqlQuery As String
    Public Property SqlQuery As String
        Set(value As String)
            _sqlQuery = value
        End Set
        Get
            Return _sqlQuery
        End Get
    End Property

    Private _dataSource As DataTable
    Public Property DataSource As DataTable
        Set(value As DataTable)
            _dataSource = value
        End Set
        Get
            Return _dataSource
        End Get
    End Property

    Private _displayMember As String
    Public Property DisplayMember As String
        Set(value As String)
            _displayMember = value
        End Set
        Get
            Return _displayMember
        End Get
    End Property

    Private _valueMember As String
    Public Property ValueMember As String
        Set(value As String)
            _valueMember = value
        End Set
        Get
            Return _valueMember
        End Get
    End Property
End Class
