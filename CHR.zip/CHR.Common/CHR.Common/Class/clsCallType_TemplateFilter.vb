﻿Public Class clsCallType_TemplateFilter
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cFilter
        MyBase._name = cFilter
        MyBase._image = cFilter
    End Sub
End Class
