﻿Public Class ClsCommonDetailItem_PictureBox
    Inherits clsCommonDetailItem

    Private _image As Image

    Public Property Image As Image
        Set(value As Image)
            _image = value
        End Set
        Get
            Return _image
        End Get
    End Property


End Class
