﻿Public Class clsCallType_TemplateReport
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cReport
        MyBase._name = cReport
        MyBase._image = cReport
    End Sub
End Class
