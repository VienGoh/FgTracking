﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DataModel.Migrations
{
    public partial class Init1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ApiProcess",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProcessStatus = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ResponseCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ResponseResult = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RetrieveFromApi = table.Column<bool>(type: "bit", nullable: false),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApiProcess", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AuditLog",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    State = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    TableName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    RecordID = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    RecordHeaderID = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    ColumnName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NewValue = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OriginalValue = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NewValue_Reshaped = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OriginalValue_Reshaped = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DocumentTypeCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLog", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AuditLogConfig",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    TableName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    FieldElementCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    SectionName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Seq = table.Column<int>(type: "int", nullable: true),
                    HeaderTableName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    HeaderIdField = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    DocumentTypeField = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    JsonVColumnName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLogConfig", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AuditLogVlookup",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TableName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    ColumnName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    VlookupTableName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    VlookupColumnName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    VlookupDisplayName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLogVlookup", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BUGroup",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    SyncVersion = table.Column<byte[]>(type: "binary(8)", fixedLength: true, maxLength: 8, nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BUGroup", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Currency",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    SyncVersion = table.Column<byte[]>(type: "binary(8)", fixedLength: true, maxLength: 8, nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Currency", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ErrorLog",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LogDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Source = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Request = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ErrorLog", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OnBehalfLog",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TableName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    RecordID = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    AddOnBehalfOf = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OnBehalfLog", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Sample",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    testA = table.Column<int>(type: "int", nullable: false),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sample", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TestTable1",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    property1 = table.Column<int>(type: "int", nullable: false),
                    property2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    property3 = table.Column<int>(type: "int", nullable: false),
                    ChildRecordId = table.Column<int>(type: "int", nullable: false),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestTable1", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestTable1_TestTable1_ChildRecordId",
                        column: x => x.ChildRecordId,
                        principalTable: "TestTable1",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TestTable2",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    property1 = table.Column<int>(type: "int", nullable: false),
                    property2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    property3 = table.Column<int>(type: "int", nullable: false),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestTable2", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TimeZone",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    ZoneInfo = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    UTCTimeZone = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Location = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    SyncVersion = table.Column<byte[]>(type: "binary(8)", fixedLength: true, maxLength: 8, nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TimeZone", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AlternateCurrency",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: true),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CurrencyId = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AlternateCurrency", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AlternateCurrency_Currency_CurrencyId",
                        column: x => x.CurrencyId,
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "System",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    UOMId = table.Column<int>(type: "int", nullable: true),
                    UOMCode = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: true),
                    CurrencyId = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_System", x => x.Id);
                    table.ForeignKey(
                        name: "FK_System_Currency_CurrencyId",
                        column: x => x.CurrencyId,
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SampleChildADetail",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SampleId = table.Column<int>(type: "int", nullable: false),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SampleChildADetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SampleChildADetail_Sample_SampleId",
                        column: x => x.SampleId,
                        principalTable: "Sample",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SampleDetail",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SampleId = table.Column<int>(type: "int", nullable: false),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SampleDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SampleDetail_Sample_SampleId",
                        column: x => x.SampleId,
                        principalTable: "Sample",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SysConfig",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SystemId = table.Column<int>(type: "int", nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SysConfig", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SysConfig_System_SystemId",
                        column: x => x.SystemId,
                        principalTable: "System",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BusinessUnit",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    Code = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    BUGroupId = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    SAPCompCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SAPLocalizationId = table.Column<int>(type: "int", nullable: true),
                    FunctionalCurrencyId = table.Column<string>(type: "nvarchar(3)", nullable: true),
                    CognosCode = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    SyncVersion = table.Column<byte[]>(type: "binary(8)", fixedLength: true, maxLength: 8, nullable: true),
                    TimeZoneId = table.Column<int>(type: "int", nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BusinessUnit", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BusinessUnit_BUGroup_BUGroupId",
                        column: x => x.BUGroupId,
                        principalTable: "BUGroup",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BusinessUnit_Currency_FunctionalCurrencyId",
                        column: x => x.FunctionalCurrencyId,
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BUSystem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BusinessUnitId = table.Column<int>(type: "int", nullable: false),
                    SystemId = table.Column<int>(type: "int", nullable: false),
                    ConnectionString = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    WebServiceURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    WebServiceSecurityKey = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CurrencyId = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: true),
                    Code = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    OpsSysProgramId = table.Column<int>(type: "int", nullable: true),
                    UOMId = table.Column<int>(type: "int", nullable: true),
                    UOMCode = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: true),
                    DefaultSOSellerId = table.Column<int>(type: "int", nullable: true),
                    DefaultSOSellerCode = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    DefaultSOSellerName = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true),
                    DefaultPOBuyerId = table.Column<int>(type: "int", nullable: true),
                    DefaultPOBuyerCode = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    DefaultPOBuyerName = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BUSystem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BUSystem_BusinessUnit_BusinessUnitId",
                        column: x => x.BusinessUnitId,
                        principalTable: "BusinessUnit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BUSystem_Currency_CurrencyId",
                        column: x => x.CurrencyId,
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BUSystem_System_SystemId",
                        column: x => x.SystemId,
                        principalTable: "System",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SysCode",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    ShortName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Sequence = table.Column<int>(type: "int", nullable: false),
                    BUSystemId = table.Column<int>(type: "int", nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SysCode", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SysCode_BUSystem_BUSystemId",
                        column: x => x.BUSystemId,
                        principalTable: "BUSystem",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserRoleBU",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Role = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    BusinessUnitId = table.Column<int>(type: "int", nullable: false),
                    BUSystemId = table.Column<int>(type: "int", nullable: true),
                    AuthorisationCode = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    WFS_DocumentId = table.Column<int>(type: "int", nullable: true),
                    WFS_StatusCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    WFS_StatusName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    AddDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    AddBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AddByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ModDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    ModDate_UTC = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModBy = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ModByUserDisplayName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Disabled = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRoleBU", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserRoleBU_BusinessUnit_BusinessUnitId",
                        column: x => x.BusinessUnitId,
                        principalTable: "BusinessUnit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserRoleBU_BUSystem_BUSystemId",
                        column: x => x.BUSystemId,
                        principalTable: "BUSystem",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AlternateCurrency_CurrencyId",
                table: "AlternateCurrency",
                column: "CurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_AlternateCurrency_Disabled",
                table: "AlternateCurrency",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_ApiProcess_Disabled",
                table: "ApiProcess",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_AuditLog_Disabled",
                table: "AuditLog",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_AuditLog_TableName_RecordID",
                table: "AuditLog",
                columns: new[] { "TableName", "RecordID" });

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogConfig_Disabled",
                table: "AuditLogConfig",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogConfig_DocumentType_TableName",
                table: "AuditLogConfig",
                columns: new[] { "DocumentType", "TableName" });

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogVlookup_Disabled",
                table: "AuditLogVlookup",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_AuditLogVlookup_TableName_ColumnName",
                table: "AuditLogVlookup",
                columns: new[] { "TableName", "ColumnName" });

            migrationBuilder.CreateIndex(
                name: "IX_BUGroup_Disabled",
                table: "BUGroup",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_BusinessUnit_BUGroupId",
                table: "BusinessUnit",
                column: "BUGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessUnit_Disabled",
                table: "BusinessUnit",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_BusinessUnit_FunctionalCurrencyId",
                table: "BusinessUnit",
                column: "FunctionalCurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessUnit_SAPLocalizationId",
                table: "BusinessUnit",
                column: "SAPLocalizationId");

            migrationBuilder.CreateIndex(
                name: "IX_BUSystem_BusinessUnitId",
                table: "BUSystem",
                column: "BusinessUnitId");

            migrationBuilder.CreateIndex(
                name: "IX_BUSystem_CurrencyId",
                table: "BUSystem",
                column: "CurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_BUSystem_Disabled",
                table: "BUSystem",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_BUSystem_SystemId",
                table: "BUSystem",
                column: "SystemId");

            migrationBuilder.CreateIndex(
                name: "IX_Currency_Disabled",
                table: "Currency",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_OnBehalfLog_Disabled",
                table: "OnBehalfLog",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_OnBehalfLog_TableName_RecordID",
                table: "OnBehalfLog",
                columns: new[] { "TableName", "RecordID" });

            migrationBuilder.CreateIndex(
                name: "IX_Sample_Disabled",
                table: "Sample",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_SampleChildADetail_Disabled",
                table: "SampleChildADetail",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_SampleChildADetail_SampleId",
                table: "SampleChildADetail",
                column: "SampleId");

            migrationBuilder.CreateIndex(
                name: "IX_SampleDetail_Disabled",
                table: "SampleDetail",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_SampleDetail_SampleId",
                table: "SampleDetail",
                column: "SampleId");

            migrationBuilder.CreateIndex(
                name: "IX_SysCode_BUSystemId",
                table: "SysCode",
                column: "BUSystemId");

            migrationBuilder.CreateIndex(
                name: "IX_SysCode_Disabled",
                table: "SysCode",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_SysConfig_Disabled",
                table: "SysConfig",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_SysConfig_SystemId",
                table: "SysConfig",
                column: "SystemId");

            migrationBuilder.CreateIndex(
                name: "IX_System_CurrencyId",
                table: "System",
                column: "CurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_System_Disabled",
                table: "System",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_TestTable1_ChildRecordId",
                table: "TestTable1",
                column: "ChildRecordId");

            migrationBuilder.CreateIndex(
                name: "IX_TestTable1_Disabled",
                table: "TestTable1",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_TestTable2_Disabled",
                table: "TestTable2",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_TimeZone_Disabled",
                table: "TimeZone",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_UserRoleBU_BusinessUnitId",
                table: "UserRoleBU",
                column: "BusinessUnitId");

            migrationBuilder.CreateIndex(
                name: "IX_UserRoleBU_BUSystemId",
                table: "UserRoleBU",
                column: "BUSystemId");

            migrationBuilder.CreateIndex(
                name: "IX_UserRoleBU_Disabled",
                table: "UserRoleBU",
                column: "Disabled")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.AddForeignKey(
                name: "FK_BusinessUnit_SysCode_SAPLocalizationId",
                table: "BusinessUnit",
                column: "SAPLocalizationId",
                principalTable: "SysCode",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BusinessUnit_BUGroup_BUGroupId",
                table: "BusinessUnit");

            migrationBuilder.DropForeignKey(
                name: "FK_BusinessUnit_SysCode_SAPLocalizationId",
                table: "BusinessUnit");

            migrationBuilder.DropTable(
                name: "AlternateCurrency");

            migrationBuilder.DropTable(
                name: "ApiProcess");

            migrationBuilder.DropTable(
                name: "AuditLog");

            migrationBuilder.DropTable(
                name: "AuditLogConfig");

            migrationBuilder.DropTable(
                name: "AuditLogVlookup");

            migrationBuilder.DropTable(
                name: "ErrorLog");

            migrationBuilder.DropTable(
                name: "OnBehalfLog");

            migrationBuilder.DropTable(
                name: "SampleChildADetail");

            migrationBuilder.DropTable(
                name: "SampleDetail");

            migrationBuilder.DropTable(
                name: "SysConfig");

            migrationBuilder.DropTable(
                name: "TestTable1");

            migrationBuilder.DropTable(
                name: "TestTable2");

            migrationBuilder.DropTable(
                name: "TimeZone");

            migrationBuilder.DropTable(
                name: "UserRoleBU");

            migrationBuilder.DropTable(
                name: "Sample");

            migrationBuilder.DropTable(
                name: "BUGroup");

            migrationBuilder.DropTable(
                name: "SysCode");

            migrationBuilder.DropTable(
                name: "BUSystem");

            migrationBuilder.DropTable(
                name: "BusinessUnit");

            migrationBuilder.DropTable(
                name: "System");

            migrationBuilder.DropTable(
                name: "Currency");
        }
    }
}
