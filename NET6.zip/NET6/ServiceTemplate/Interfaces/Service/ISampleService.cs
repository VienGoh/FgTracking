using DataModel.Contexts;
using DataModel.Entities;
using Microsoft.AspNetCore.Mvc;
using MMH.HelperService.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceTemplate.Interfaces.Service
{
  public interface ISampleService : IBaseService<LocalDbContext, Sample>
  {
    public List<Sample> TestEFDynamicQuery();
    public Sample GetWorkFlowByDocumentId(int rDocumentId);
    public List<Sample> GetAllSample();
    public Sample CustomizeOwnAddRecord();
    public Sample CustomizeOwnUpdateRecord(Sample obj);

  }

  public interface ISampleDetailService : IBaseService<LocalDbContext, SampleDetail>
  {
    public SampleDetail TestA(int id);
    public SampleDetail CustomizeOwnAddRecordWithCascadeAdd();
    public SampleDetail CustomizeOwnUpdateRecordWithCascadeUpdate(SampleDetail obj);
  }
}
