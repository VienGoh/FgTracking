using DataModel.Contexts;
using DataModel.Entities;
using Microsoft.AspNetCore.Mvc;
using MMH.DataContextModel.Contexts;
using MMH.DataContextModel.Entities;
using MMH.HelperService.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceTemplate.Interfaces.Service
{
  public interface ISysCodeService : IBaseService<dbContext, SysCode>
  {
    public SysCode GetSysCode(string type, string code, int? buSystemId = null);
    public List<SysCode> GetSysCodes(string type, int? buSystemId = null);
  }
}
