using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataModel.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Migrations.Design;
using MMH.DataContextModel.Contexts;
using MMH.DataContextModel.Extensions;
using MMH.DataContextModel.Migrations;

namespace DataModel.Contexts
{
  public class LocalDbContext : dbContext
  {
    public static bool ValidateDatabaseModel = false;
    public LocalDbContext(DbContextOptions<LocalDbContext> options) : base(options)
    {
      if (ValidateDatabaseModel)
      {
        var pendingMigrations = this.Database.GetPendingMigrations().ToList();
        if (pendingMigrations.Any() || !this.Database.GetMigrations().Contains(this.Database.GetAppliedMigrations().ToList().Last()))
        {
          throw new Exception("The Database Schema Changed.Please Check the migration version");

        }
      }
    }
    #region "Data Set"

    public DbSet<TestTable1> TestTable1s { get; set; }
    public DbSet<TestTable2> TestTable2s { get; set; }




    public DbSet<Sample> Samples { get; set; }
    public DbSet<SampleDetail> SampleDetails { get; set; }
    public DbSet<SampleChildADetail> SampleChildADetails { get; set; }

    #endregion

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      base.OnModelCreating(modelBuilder);
      modelBuilder.ApplyE1StandardOnModelCreating();

    }


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
      optionsBuilder.AddInterceptors(new EFCommandInterceptor());
    }




  }
}
