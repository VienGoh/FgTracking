﻿Imports CHR.Common

Public Class clsCallType
    Implements iclsCallType

    Protected Property _friendlyName As String
    Public Property FriendlyName As String Implements iclsCallType.FriendlyName
        Get
            Return _friendlyName
        End Get
        Set(value As String)
            _friendlyName = value
        End Set
    End Property

    Protected Property _image As String
    Public Property Image As String Implements iclsCallType.Image
        Get
            Return _image
        End Get
        Set(value As String)
            _image = value
        End Set
    End Property

    Protected Property _name As String
    Public Property Name As String Implements iclsCallType.Name
        Get
            Return _name
        End Get
        Set(value As String)
            _name = value
        End Set
    End Property
End Class
