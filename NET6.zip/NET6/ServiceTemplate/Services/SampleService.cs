using DataModel.Contexts;
using DataModel.Entities;
using MMH.DataContextModel.Entities;
using MMH.HelperService.Interfaces.Repositories;
using MMH.HelperService.Interfaces.Services;
using MMH.HelperService.Services;
using ServiceTemplate.Interfaces.Repo;
using ServiceTemplate.Interfaces.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using MMHContext = MMH.DataContextModel.Contexts.dbContext;

namespace ServiceTemplate.Services
{
  public class SampleService : BaseService<LocalDbContext, Sample>, ISampleService
  {
    private readonly IBaseRepository<MMHContext, SysCode> _sysCodeRepo;
    private readonly ISampleRepository _repo;
    private readonly ISysCodeService _sysCodeSvc;
    public SampleService(ISampleRepository repo,IBaseRepository<MMHContext, SysCode> sysCodeRepo,ISysCodeService sysCodeService) : base(repo) {
      _sysCodeRepo = sysCodeRepo;
      _repo = repo;
      _sysCodeSvc = sysCodeService;
    }

    public List<Sample> GetAllSample()
    {
      List<Sample> sampleList = GetAll().ToList();
      List<SysCode> sysCodeList = _sysCodeRepo.GetAll().ToList();
      // Own logic
      // { . . . }
      return sampleList;
    }

    public Sample CustomizeOwnAddRecord()
    {
      Sample zzz = _repo.CustomizeOwnAddRecord();

      return zzz;
    }
    public Sample CustomizeOwnUpdateRecord(Sample obj)
    {
      Sample zzz = _repo.CustomizeOwnUpdateRecord(obj);

      return zzz;
    }


    public Sample GetWorkFlowByDocumentId(int rDocumentId)
    {
      //Retrieve record with WFS DocumentID
      var relatedRecord = GetByWFSDocumentId(rDocumentId);

      //Retrieval purpose
      int getValue = relatedRecord.testA;

      //Modification purpose
      relatedRecord.testA = 888;
      this.Update(relatedRecord);

      return relatedRecord;
    }


    public List<Sample> TestEFDynamicQuery()
    {
      _sysCodeSvc.GetSysCodes("");


      return new List<Sample>();
    }
  }

  public class SampleDetailService : BaseService<LocalDbContext, SampleDetail>, ISampleDetailService
  {
    private readonly ISampleDetailRepository _repo;
    public SampleDetailService(ISampleDetailRepository repo) : base(repo)
    {
      _repo = repo;
    }

    public SampleDetail TestA(int id)
    {
      return _repo.TestA(id);
    }
    public SampleDetail CustomizeOwnAddRecordWithCascadeAdd()
    {
      return _repo.CustomizeOwnAddRecordWithCascadeAdd();
    }
    public SampleDetail CustomizeOwnUpdateRecordWithCascadeUpdate(SampleDetail obj)
    {
      return _repo.CustomizeOwnUpdateRecordWithCascadeUpdate(obj);
    }
  }


  public static class ExpressionHelper
  {
    public static Expression GetPropertyExpression(Expression pe, string chain)
    {
      if (string.IsNullOrWhiteSpace(chain))
        throw new ArgumentException("Chain cannot be null or empty.", nameof(chain));

      var properties = chain.Split('.');

      foreach (var property in properties)
      {
        var propertyInfo = pe.Type.GetProperty(property);
        if (propertyInfo == null)
        {
          throw new ArgumentException($"Property '{property}' not found in type '{pe.Type}'.");
        }

        pe = Expression.Property(pe, propertyInfo);
      }

      return pe;
    }
  }




}
