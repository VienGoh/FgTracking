using DataModel.Contexts;
using DataModel.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MMH.HelperController.Utilities;
using ServiceTemplate.Interfaces.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;
using Telerik.Barcode;
using MMH.DataContextModel.Contexts;
using WebApiUtilities;
using RestSharp;
using Newtonsoft.Json;

namespace TemplateProjectCore.Controllers
{
  [ApiController]
  public class SamplesController : BaseController<LocalDbContext, Sample>
  {
    public ISampleService _svc;
    public SamplesController(ISampleService svc) : base(svc)
    {
      _svc = svc;
    }

    [HttpGet("GetAllSample")]
    public IActionResult GetAllSample()
    {
      List<Sample> sampleList = _svc.GetAllSample();
      return Ok(sampleList);
    }

    [HttpPut("CustomizeOwnUpdateRecord/{id}")]
    public IActionResult CustomizeOwnUpdateRecord([FromRoute] int id, [FromBody] Sample obj)
    {
      Sample sampleList = _svc.CustomizeOwnUpdateRecord(obj);
      return Ok(sampleList);
    }

    [HttpPost("CustomizeOwnAddRecord")]
    public IActionResult CustomizeOwnAddRecord([FromBody] Sample obj)
    {
      Sample sampleList = _svc.CustomizeOwnAddRecord();
      return Ok(sampleList);
    }


    [HttpGet("GetWorkFlowByDocumentId/{rDocumentId}")]
    public IActionResult GetWorkFlowByDocumentId([FromRoute] int rDocumentId)
    {
      Sample relatedRecord = _svc.GetWorkFlowByDocumentId(rDocumentId);

      return Ok();
    }

    [HttpGet("CustomizeOwnAddRecord")]
    public IActionResult CustomizeOwnAddRecord()
    {

      ClientSercretToken111 value = new ClientSercretToken111
      {
        clientSecret = "mZq4t7w!z%C*F)J@",
        clientHostName = Environment.MachineName
      };
      var ggg = JsonConvert.SerializeObject(value);

      WebApiManager.ConfigureWebApiClientCredentials("https://oauthuat.musimmas.com/jwttoken", "ICOF-104489'", "P-EMS", "mZq4t7w!z%C*F)J@"); 
      //WebApiManager.ConfigureWebApiClientCredentials("https://oauthuat.musimmas.com/jwttoken", "ICOF-104605", "P-EMS", "mZq4t7w!z%C*F)J@");
      //WebApiManager.ConfigureWebApiClientCredentials("https://oauthuat.musimmas.com/jwttoken", "ICOF-5dsada", "P-EMS", "mZq4t7w!z%C*F)J@");
      // WebApiManager.ConfigureWebApiClientCredentials("https://oauthuat.musimmas.com/jwttoken", "ICOF-530", "P-EMS", "mZq4t7w!z%C*F)J@");
      //WebApiManager.ConfigureWebApiClientCredentials("https://oauthuat.musimmas.com/jwttoken", "EAS_Application", "EAS", "2x3V@uJAb54r!y#");
      //WebApiManager.ConfigureWebApiClientCredentials("https://oauthuat.musimmas.com/jwttoken", "EAS_Application", "EAS", "2x3V@uJAb54r!y#");
      var sku1 = WebApiManager.InvokeWebApi<object>("https://e1uat.musimmas.com/PEMSWeb_Api/api/SystemAccess/GetProjectAccessRequestReport/2314/", Method.GET, null, null, null).Result;




      Sample sampleList = _svc.CustomizeOwnAddRecord();
      return Ok(sampleList);
    }


    private class ClientSercretToken111
    {
      public string clientSecret { get; set; }

      public string clientHostName { get; set; }
    }

    //public override IActionResult Get(int id)
    //{
    //  if (HttpContext.Request.Headers.TryGetValue("Uniqueidentifier", out var headerValue))
    //  {
    //    string aaa = headerValue;
    //    // Use the headerValue here or perform any other logic based on the header value
    //    //return Ok($"Value of Your-Header-Name: {headerValue}");
    //  }


    //  LocalDbContext xxxvv = null;
    //  try
    //  {
    //    var optionsBuilder = new DbContextOptionsBuilder<LocalDbContext>();
    //    optionsBuilder.UseSqlServer(@"Data Source=(localdb)\ProjectModels; Database = zzzz; user id = piaw; password = piaw1212; connect timeout = 30; MultipleActiveResultSets = True;App=EntityFramework");
    //    xxxvv = new LocalDbContext(optionsBuilder.Options);
    //  }
    //  catch (Exception ex)
    //  {

    //  }
    //  Thread.Sleep(3 * 1000);
    //  Sample obj = xxxvv.Samples.FirstOrDefault(x => x.Id == id);

    //  //object obj = svc.GetByIdAsObject(id);
    //  if (obj == null)
    //  {
    //    return NotFound();
    //  }
    //  return Ok(obj);

    //  Thread.Sleep(3 * 1000);
    //  List<int> sss = new List<int>();
    //  sss.Add(222);
    //  sss.Add(333);
    //  sss.Add(444);
    //  sss.Add(555);
    //  return Ok(sss);
    //}

    //public override IActionResult Put([FromRoute] int id, [FromBody] Sample obj)
    //{

    //  return base.Put(id, obj);

    //  LocalDbContext xxxvv = null;
    //  try
    //  {
    //    var optionsBuilder = new DbContextOptionsBuilder<LocalDbContext>();
    //    optionsBuilder.UseSqlServer(@"Data Source=(localdb)\ProjectModels; Database = zzzz; user id = piaw; password = piaw1212; connect timeout = 30; MultipleActiveResultSets = True;App=EntityFramework");
    //    xxxvv = new LocalDbContext(optionsBuilder.Options);
    //  }
    //  catch (Exception ex)
    //  {

    //  }
    //  Thread.Sleep(3 * 1000);
    //  var modifiedEntries = xxxvv.ChangeTracker.Entries<Sample>().Where(e => e.State == EntityState.Modified);
    //  Sample original = xxxvv.Samples.FirstOrDefault(x => x.Id == obj.Id);
    //  original.ModByUserDisplayName = "niamamama";
    //  original.testA = obj.testA;
    //  xxxvv.Set<Sample>().Update(original);
    //  xxxvv.SaveChanges();
    //  var modifiedEntries222 = xxxvv.ChangeTracker.Entries<Sample>().Where(e => e.State == EntityState.Modified);

    //  return Ok(xxxvv.Samples.FirstOrDefault(x => x.Id == obj.Id));
    //}

    public override IActionResult Post(Sample obj)
    {
      return base.Post(obj);
    }

    [HttpGet("TestEFDynamicQuery")]
    public IActionResult TestEFDynamicQuery()
    {

      var ggggggg = _svc.TestEFDynamicQuery();




      return Ok();
    }

  }

  //[Authorize]
  [ApiController]
  [Route("api/PageSamples")]
  public class PageSamplesController : PageBaseController<LocalDbContext, Sample>
  {
    public PageSamplesController(ISampleService svc) : base(svc)
    {

    }
  }


  [Authorize]
  [ApiController]
  //[Route("api/[controller]")]
  public class SampleDetailsController : BaseController<LocalDbContext, SampleDetail>
  {
    public ISampleDetailService _svc;
    public SampleDetailsController(ISampleDetailService svc) : base(svc)
    {
      _svc = svc;
    }

    [HttpGet("CustomizeOwnAddRecordWithCascadeAdd")]
    public IActionResult CustomizeOwnAddRecordWithCascadeAdd()
    {
      SampleDetail sampleList = _svc.CustomizeOwnAddRecordWithCascadeAdd();
      return Ok(sampleList);
    }
    
    [HttpPut("CustomizeOwnUpdateRecordWithCascadeUpdate/{id}")]
    public IActionResult CustomizeOwnUpdateRecordWithCascadeUpdate([FromRoute] int id, [FromBody] SampleDetail obj)
    {
      SampleDetail sampleList = _svc.CustomizeOwnUpdateRecordWithCascadeUpdate(obj);
      return Ok(sampleList);
    }

  }

  //[Authorize]
  [ApiController]
  [Route("api/PageSampleDetails")]
  public class PageSampleDetailsController : PageBaseController<LocalDbContext, SampleDetail>
  {
    private readonly ISampleDetailService _svc;
    public PageSampleDetailsController(ISampleDetailService svc) : base(svc)
    {
      _svc = svc;
    }

    [HttpGet("GetById/{id}")]
    public IActionResult GetById(int id)
    {
      return Ok(_svc.TestA(id));
    }

  }


}
