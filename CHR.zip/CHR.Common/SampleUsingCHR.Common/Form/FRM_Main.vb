﻿Imports CHR.Common
Public Class FRM_Main
    Private Sub ItemToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ItemToolStripMenuItem.Click
        Dim fItem As New frmList(New clsMasterItem) With {.Text = "Master Item", .IsAutoRefresh = True, .AutoRefreshDuration = 5}
        fItem.Show()
        fItem.MdiParent = Me
    End Sub

End Class
