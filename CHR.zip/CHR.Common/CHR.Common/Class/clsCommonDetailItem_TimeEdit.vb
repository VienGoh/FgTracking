﻿Public Class clsCommonDetailItem_TimeEdit
    Inherits clsCommonDetailItem

    Private _timeFormat As String = "HH:mm:ss"
    Public Property TimeFormat As String
        Set(value As String)
            _timeFormat = value
        End Set
        Get
            Return _timeFormat
        End Get
    End Property
End Class
