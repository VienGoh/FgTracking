using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using DataModel.Contexts;
using DataModel.Entities;
using Microsoft.EntityFrameworkCore;
using MMH.HelperService.Repositories;
using MMH.HelperUtilities.Utilities;
using ServiceTemplate.Interfaces.Repo;

namespace ServiceTemplate.Repositories
{
  public class SampleRepository : BaseRepository<LocalDbContext, Sample>, ISampleRepository
  {
    private readonly LocalDbContext _dbContext;
    private IPrincipal _principal;
    public SampleRepository(LocalDbContext context, IPrincipal pctx) : base(context, pctx)
    {
      _dbContext = context;
      _principal = pctx;
    }

    public override Sample Add(Sample entity, bool? cascadeAdd = null)
    {
      //Own Logic

      return base.Add(entity, cascadeAdd);
    }


    public override void Update(Sample entity)
    {
      //Own Logic

      base.Update(entity);
    }

    public Sample CustomizeOwnAddRecord()
    {
      Sample newRecord = new Sample();
      newRecord.testA = 88888;
      //Use Library method to add record
      Add(newRecord);

      //Customized own add record without using library
      Helper.setPostData(newRecord, _principal);  //Define AddDate,AddBy default columns
      _dbContext.Samples.Add(newRecord);          //Add newRecord into the Sample table

      executeAuditlogAction = GetAuditLogData();  //Track into AuditLog Table
      executeSignalRAuditlogAction = GetSignalRAuditLogData();  //Feedback Changes to FrontEnd
      _dbContext.SaveChanges();
      executeAuditlogAction.Invoke().Wait();
      var result = executeSignalRAuditlogAction().Result;

      return newRecord;
    }

    public Sample CustomizeOwnUpdateRecord(Sample obj)
    {
      obj.testA = 88888; //modify based on own logic or validation
      //Use Library method to update record
      Update(obj);

      //OR retrieval and modify 
      Sample databaseRecord = FindById(obj.Id);
      databaseRecord.testA = 16888;
      Update(databaseRecord);

      //Customized own modify record without using library
      //
      // Do necessary  modication or validation here
      //
      Helper.setPutData(obj, _principal);  //Define ModDate,ModBy default columns
      _dbContext.Samples.Update(obj);          //update this record in the Sample table

      executeAuditlogAction = GetAuditLogData();  //Track into AuditLog Table
      executeSignalRAuditlogAction = GetSignalRAuditLogData();  //Feedback Changes to FrontEnd
      _dbContext.SaveChanges();
      executeAuditlogAction.Invoke().Wait();
      var result = executeSignalRAuditlogAction().Result;

      return obj;
    }
  }

  public class SampleDetailRepository : BaseRepository<LocalDbContext, SampleDetail>, ISampleDetailRepository
  {
    private readonly LocalDbContext _context;
    private IPrincipal _principal;
    public SampleDetailRepository(LocalDbContext context, IPrincipal pctx) : base(context, pctx)
    {
      _context = context;
      _principal = pctx;
    }


    public SampleDetail CustomizeOwnAddRecordWithCascadeAdd()
    {
      Sample newSampleRecord = new Sample();
      newSampleRecord.testA = 16888;
      SampleDetail newSampleDetailRecord = new SampleDetail();
      newSampleDetailRecord.testAAA = newSampleRecord;

      //Use Library method to add record
      SetCascadeAdd(true);
      Add(newSampleDetailRecord);
      SetCascadeAdd(false);

      //Customized own add record without using library
      Helper.setPostData(newSampleRecord, _principal);  //Define AddDate,AddBy default columns
      Helper.setPostData(newSampleDetailRecord, _principal);  //Define AddDate,AddBy default columns
      _context.SampleDetails.Add(newSampleDetailRecord);          //Add newRecord into the Sample table

      executeAuditlogAction = GetAuditLogData();  //Track into AuditLog Table
      executeSignalRAuditlogAction = GetSignalRAuditLogData();  //Feedback Changes to FrontEnd
      _context.SaveChanges();
      executeAuditlogAction.Invoke().Wait();
      var result = executeSignalRAuditlogAction().Result;

      return newSampleDetailRecord;
    }
    public SampleDetail CustomizeOwnUpdateRecordWithCascadeUpdate(SampleDetail obj)
    {
      //Modify the parent record
      Sample parentSampleRecord = obj.testAAA;
      parentSampleRecord.testA = 16888;

      //Use Library method to update record
      SetCascadeUpdate(true);
      Update(obj);
      SetCascadeUpdate(false);

      //OR retrieval and modify the parent record
      SampleDetail databaseRecord = FindById(obj.Id);
      Sample parentRecord = databaseRecord.testAAA;
      parentRecord.testA = 88888;

      //Use Library method to update record
      SetCascadeUpdate(true);
      Update(obj);
      SetCascadeUpdate(false);

      //Customized own modify record without using library
      //
      // Do necessary  modication or validation here
      //
      Helper.setPutData(obj, _principal);  //Define ModDate,ModBy default columns
      _context.SampleDetails.Update(obj);          //update this record in the Sample table

      executeAuditlogAction = GetAuditLogData();  //Track into AuditLog Table
      executeSignalRAuditlogAction = GetSignalRAuditLogData();  //Feedback Changes to FrontEnd
      _context.SaveChanges();
      executeAuditlogAction.Invoke().Wait();
      var result = executeSignalRAuditlogAction().Result;

      return obj;
    }



    public SampleDetail TestA(int id)
    {
      SampleDetail aaa = _context.SampleDetails.Include(x => x.testAAA).Where(x => x.Id == id).FirstOrDefault();

      return aaa;

    }

  }
}
