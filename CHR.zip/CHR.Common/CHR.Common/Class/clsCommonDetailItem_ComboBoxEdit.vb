﻿Public Class clsCommonDetailItem_ComboBoxEdit
    Inherits clsCommonDetailItem

    Private _items() As String
    Public Property Items As String()
        Set(value As String())
            _items = value
        End Set
        Get
            Return _items
        End Get
    End Property
End Class
