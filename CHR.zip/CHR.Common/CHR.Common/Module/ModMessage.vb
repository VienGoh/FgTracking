﻿Public Module modMessage
    Public Sub mbError(ByVal Text As String, ByVal Optional Caption As String = "Error")
        MessageBox.Show(Text, Caption, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Public Sub mbInfo(ByVal Text As String, ByVal Optional Caption As String = "Information")
        MessageBox.Show(Text, Caption, MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Public Function mbAsk(ByVal Text As String, ByVal Optional Caption As String = "Confirm") As DialogResult
        Return MessageBox.Show(Text, Caption, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
    End Function
End Module
