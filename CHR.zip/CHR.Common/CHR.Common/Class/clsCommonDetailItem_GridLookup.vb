﻿Public Class clsCommonDetailItem_GridLookup
    Inherits clsCommonDetailItem

    Private _connectionString As String
    Public Property ConnectionString As String
        Set(value As String)
            _connectionString = value
        End Set
        Get
            Return _connectionString
        End Get
    End Property

    Private _sqlQuery As String
    Public Property SqlQuery As String
        Set(value As String)
            _sqlQuery = value
        End Set
        Get
            Return _sqlQuery
        End Get
    End Property

    Private _dataSource As DataTable
    Public Property DataSource As DataTable
        Set(value As DataTable)
            _dataSource = value
        End Set
        Get
            Return _dataSource
        End Get
    End Property

    Private _isMultiSelect As Boolean = False
    Public Property IsMultiSelect As Boolean
        Set(value As Boolean)
            _isMultiSelect = value
        End Set
        Get
            Return _isMultiSelect
        End Get
    End Property

    Private _lookupAndAffectedRow(,) As String
    Public Property LookupAndAffectedRow As String(,)
        Set(value As String(,))
            _lookupAndAffectedRow = value
        End Set
        Get
            Return _lookupAndAffectedRow
        End Get
    End Property

    Private _separator As String = ","
    Public Property Separator As String
        Set(value As String)
            _separator = value
        End Set
        Get
            Return _separator
        End Get
    End Property

    Private _enableFreeText As Boolean
    Public Property EnableFreeText As Boolean
        Set(value As Boolean)
            _enableFreeText = value
        End Set
        Get
            Return _enableFreeText
        End Get
    End Property

    Private _DockToolStrip As DockStyle = DockStyle.Top
    Public Property DockToolStrip As DockStyle
        Get
            Return _DockToolStrip
        End Get
        Set(value As DockStyle)
            _DockToolStrip = value
        End Set
    End Property




End Class
