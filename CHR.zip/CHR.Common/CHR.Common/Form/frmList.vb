﻿Imports System.Text.RegularExpressions
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.Utils
Imports DevExpress.XtraGrid.Columns
Imports DevExpress.XtraEditors
Imports DevExpress.XtraGrid

Public Class frmList

    Private _clsList As iclsList

    Private Property _isMultiSelect As Boolean = False
    Public WriteOnly Property IsMultiSelect As Boolean
        Set(value As Boolean)
            _isMultiSelect = value
        End Set
    End Property

    Private Property _refreshOnLoad As Boolean = True
    Public WriteOnly Property RefreshOnLoad As Boolean
        Set(value As Boolean)
            _refreshOnLoad = value
        End Set
    End Property

    Private Property _isGridEditable As Boolean = False
    Public WriteOnly Property IsGridEditable As Boolean
        Set(value As Boolean)
            _isGridEditable = value
        End Set
    End Property

    Private Property _isAutoRefresh As Boolean = False
    Public WriteOnly Property IsAutoRefresh As Boolean
        Set(value As Boolean)
            _isAutoRefresh = value
        End Set
    End Property

    Private Property _autoRefreshDuration As Integer = 60
    Public WriteOnly Property AutoRefreshDuration As Integer
        Set(value As Integer)
            _autoRefreshDuration = value
        End Set
    End Property

    Public ReadOnly Property GridViewVariable As GridView
        Get
            Return GridView1
        End Get
    End Property

    Private Property dt As DataTable = Nothing



    Public Sub New(clsList As iclsList)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        _clsList = clsList
    End Sub

    Private Sub frmList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each ctl As iclsCallType In _clsList.CallTypeList
            Dim tsb As New ToolStripButton With {
                .Name = ctl.Name,
                .Text = ctl.FriendlyName,
                .DisplayStyle = ToolStripItemDisplayStyle.ImageAndText,
                .ImageScaling = ToolStripItemImageScaling.None,
                .TextImageRelation = TextImageRelation.ImageAboveText,
                .Image = My.Resources.ResourceManager.GetObject(ctl.Image)}

            AddHandler tsb.Click, AddressOf btnAction_Click
            ToolStrip1.Items.Add(tsb)
        Next

        If _refreshOnLoad Then
            DoRefresh()
        Else
            lblAddonText.Visible = False
        End If
        GridView1.OptionsBehavior.Editable = _isGridEditable
        GridView1.OptionsBehavior.ReadOnly = True

        If _isMultiSelect Then
            GridView1.OptionsSelection.MultiSelect = True
            GridView1.OptionsSelection.MultiSelectMode = GridMultiSelectMode.CheckBoxRowSelect
        End If

        If _isAutoRefresh Then
            Timer1.Enabled = True
            Timer1.Interval = _autoRefreshDuration * 1000
        End If
    End Sub

    Private Sub btnAction_Click(sender As Object, e As EventArgs)
        Dim IsRefresh As Boolean
        IsRefresh = _clsList.Action(GridView1.GetFocusedDataRow, CType(sender, ToolStripButton).Name)

        If IsRefresh Then DoRefresh()
    End Sub

    Private Sub DoRefresh()
        SetEnableToolStripButton(False)
        ProgressPanel1.Left = Width \ 2 - ProgressPanel1.Width \ 2
        ProgressPanel1.Top = Height \ 2 - ProgressPanel1.Height \ 2
        ProgressPanel1.Visible = True
        BackgroundWorker1.RunWorkerAsync()
    End Sub

    Private Sub RefreshGridData()
        'Dim dt As DataTable = _clsList.RefreshData()
        If IsNothing(dt) Then
            GridControl1.DataSource = Nothing
            mbInfo("No data.")
            Exit Sub
        End If

        GridControl1.DataSource = dt

        'jika ada perubahan di dt, maka perlu add line ini
        GridView1.Columns.Clear()
        GridView1.FormatRules.Clear()
        GridView1.PopulateColumns()

        lblRowCount.Text = If(dt.Rows.Count > 0, dt.Rows.Count & If(dt.Rows.Count > 1, " Rows", " Row"), "No Row")

        'rename Grid Column Header
        'format Grid Column
        Dim _customFormat As Dictionary(Of String, String)
        _customFormat = _clsList.CustomFormat
        Dim _conditionalFormat As Dictionary(Of String, FormatConditionRuleExpression)
        _conditionalFormat = _clsList.ConditionalFormat
        Dim _sumColumn As List(Of GridColumnSummaryItem)
        _sumColumn = _clsList.SummaryColumn
        Dim _groupSum As List(Of GridGroupSummaryItem)
        _groupSum = _clsList.GroupSum
        GridView1.GroupSummary.Clear()

        'kelvin 29/9/2022 variabel untuk pengisian ukuran teks
        Dim _fontGridView As Object
        _fontGridView = _clsList.FontGridView

        If dt.Rows.Count > 0 Then
            For i As Byte = 0 To dt.Columns.Count - 1
                If _customFormat IsNot Nothing Then
                    Dim formatString As String = ""
                    If _customFormat.TryGetValue(dt.Columns(i).ColumnName, formatString) Then
                        GridView1.Columns(i).DisplayFormat.FormatType = FormatType.Custom
                        GridView1.Columns(i).DisplayFormat.FormatString = formatString
                    End If
                End If

                If _conditionalFormat IsNot Nothing Then
                    Dim conditionalFormat As New FormatConditionRuleExpression
                    If _conditionalFormat.TryGetValue(dt.Columns(i).Caption, conditionalFormat) Then
                        Dim gridFormatRule As New GridFormatRule
                        gridFormatRule.Name = dt.Columns(i).Caption
                        gridFormatRule.Column = GridView1.Columns(dt.Columns(i).Caption)
                        gridFormatRule.ColumnApplyTo = GridView1.Columns(dt.Columns(i).Caption)
                        gridFormatRule.Rule = conditionalFormat

                        Dim iterateI As Integer = i
                        If Not GridView1.FormatRules.Where(Function(o) o.Name = dt.Columns(iterateI).Caption).Any Then GridView1.FormatRules.Add(gridFormatRule)
                    End If
                End If

                Dim colCaption As String = dt.Columns(i).Caption.Replace("_", " ")
                colCaption = Regex.Replace(colCaption, "([a-z])([A-Z])", "$1 $2").ToUpper
                TryCast(GridControl1.MainView, GridView).Columns(i).Caption = colCaption
            Next
        End If

        'dipindahkan ke bawah
        'GridView1.BestFitColumns()

        If IsNulls(_clsList.ColumnNumToFreeze, "") <> "" Then
            Dim nums() As String = _clsList.ColumnNumToFreeze.Replace(" ", "").Split("-")
            For i As Integer = nums(0) To nums(1)
                GridView1.Columns(i).Fixed = FixedStyle.Left
            Next
        End If

        If _sumColumn IsNot Nothing Then
            For Each colSum As GridColumnSummaryItem In _sumColumn
                GridView1.Columns(colSum.FieldName).Summary.Add(colSum)
            Next
        End If

        If _groupSum IsNot Nothing Then
            For Each groupSum As GridGroupSummaryItem In _groupSum
                GridView1.GroupSummary.Add(groupSum)
            Next
        End If


        '9/29/2022 kelvin ini difungsikan untuk mengubah ukuran teks pada grid view
        If _fontGridView IsNot Nothing Then
            GridView1.Appearance.EvenRow.Font = _fontGridView
            GridView1.Appearance.EvenRow.Options.UseFont = True
            GridView1.Appearance.Row.Font = _fontGridView
            GridView1.Appearance.Row.Options.UseFont = True
            GridView1.Appearance.HeaderPanel.Font = _fontGridView
            GridView1.Appearance.HeaderPanel.Options.UseFont = True
        End If

        GridView1.BestFitColumns()

        If _groupSum IsNot Nothing Then
            For Each groupSum As GridGroupSummaryItem In _groupSum
                GridView1.GroupSummary.Add(groupSum)
            Next
        End If

        GridViewCustomFormat()
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        dt = _clsList.RefreshData()
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        RefreshGridData()
        ProgressPanel1.Visible = False
        SetEnableToolStripButton(True)
        lblAddonText.Visible = True
        lblAddonText.Text = IsNulls(_clsList.AddonText, "")
    End Sub

    Private Sub SetEnableToolStripButton(ByVal IsEnable As Boolean)
        For Each tsb As ToolStripButton In ToolStrip1.Items.OfType(Of ToolStripButton)
            tsb.Enabled = IsEnable
        Next
    End Sub

    Public Overridable Sub GridView1_DoubleClick(sender As Object, e As EventArgs) Handles GridView1.DoubleClick

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        DoRefresh()
    End Sub

    Private Sub frmList_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

    Private Sub GridView1_RowStyle(sender As Object, e As RowStyleEventArgs) Handles GridView1.RowStyle
        Dim gv As GridView = CType(sender, GridView)
        Dim _conditionalFormat As Dictionary(Of String, FormatConditionRuleExpression)
        _conditionalFormat = _clsList.ConditionalFormat
        If Not IsNothing(dt) And Not IsNothing(_conditionalFormat) Then
            For i As Byte = 0 To dt.Columns.Count - 1
                Dim conditionalFormat As New FormatConditionRuleExpression
                If _conditionalFormat.TryGetValue("RowFormat" & dt.Columns(i).Caption, conditionalFormat) Then
                    If e.RowHandle >= 0 Then
                        If conditionalFormat.Expression.Contains("EQUALS") Then
                            If IsNulls(gv.GetRowCellValue(e.RowHandle, gv.Columns(dt.Columns(i).Caption)), "") = conditionalFormat.Expression.Split("=")(1) Then
                                e.Appearance.BackColor = conditionalFormat.Appearance.BackColor
                            End If
                        ElseIf conditionalFormat.Expression.Contains("CONTAINS") Then
                            If IsNulls(gv.GetRowCellValue(e.RowHandle, gv.Columns(dt.Columns(i).Caption)), "").ToString.Contains(conditionalFormat.Expression.Split("=")(1)) Then
                                e.Appearance.BackColor = conditionalFormat.Appearance.BackColor
                            End If
                        End If
                    End If
                End If
            Next
        End If
    End Sub

    Public Overridable Sub GridViewCustomFormat()

    End Sub
End Class