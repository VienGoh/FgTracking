﻿Public Class clsCallType_TempateDelete
    Inherits clsCallType

    Public Sub New()
        MyBase._friendlyName = cDelete
        MyBase._name = cDelete
        MyBase._image = cDelete
    End Sub
End Class
