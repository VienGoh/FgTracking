using Microsoft.AspNetCore.Http;
using MMH.DataContextModel.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HUUtilities = MMH.HelperUtilities.Utilities;

namespace TemplateProjectCore.Middlewares
{
    /// <summary>
    /// We need to do this because of the ConnectionStringBuilder.
    /// in order to generate the UserConnectionString it needs the UserId from the Token, 
    /// but when we use APIFilter it is too late as DBContext created when WebApi Controller instace created.
    /// 
    /// MessageHandler below is executed before the WebApiController instance created.
    /// </summary>
    public class MessageHandlerInterceptor
    {
        private readonly RequestDelegate _next;
        //private readonly IPrincipal pctx = new GenericPrincipal(new GenericIdentity("piaw"), new string[] { "Developer" });

        public MessageHandlerInterceptor(RequestDelegate next)
        {
            _next = next;
            //Thread.CurrentPrincipal = pctx;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                //Thread.CurrentPrincipal = pctx;
                //var context = ((OwinContext)request.Properties["MS_OwinContext"]); 

                if (context != null && context.User != null)
                {
                    // var token = new JwtSecurityTokenHandler().ReadJwtToken(context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last());
                    //var identity = new ClaimsPrincipal(new ClaimsIdentity(token.Claims));


                    //Thread.CurrentPrincipal = identity;
                    UserSession.Session = new UserSession(context.User);
                    HUUtilities.Utils.Session = UserSession.Session;
                }
            }
            catch (Exception ex)
            {

            }

            // do custom stuff here with service    
            //await _next.Invoke(context);
            await _next(context);
        }
    }
}
